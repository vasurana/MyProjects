package com.example.demo1;



public class Json {
	
	private String id;
	private String deviceId;
	private boolean VideoOn;

}
