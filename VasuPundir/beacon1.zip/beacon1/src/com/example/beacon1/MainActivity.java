package com.example.beacon1;

import java.util.ArrayList;
import java.util.Collection;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.Identifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;

import com.sensoro.beacon.kit.BeaconManagerListener;
import com.sensoro.cloud.SensoroManager;

import android.support.v7.app.ActionBarActivity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.os.Vibrator;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

	SensoroManager sensoroManager;
	TextView tvDistance1, tvDistance2, tvNearestBeacon, tvOfferNike, tvOfferAdidas;
	String beaconDistance1 = null;
	String beaconDistance2 = null;
	double distance1 = 0;
	double distance2 = 0;
	ImageView iv;
	Handler mHandler = new Handler();
	Vibrator vibrator;
	Notification AdidasNote, NikeNote;
	NotificationManager mgr;
	Runnable runnableNike = new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			mgr.notify(9999, NikeNote);
	        tvOfferNike.setText("OFFER OFFER!! 45% off on Nike products. HURRY!!");
	        tvOfferNike.setTextSize(25);
	        tvOfferNike.setVisibility(View.VISIBLE);
	        tvOfferNike.setTextColor(Color.BLUE); 
	        tvOfferNike.setBackgroundColor(Color.BLACK);
		}
	};
	Runnable runnableAdidas = new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			mgr.notify(8888, AdidasNote);
	        tvOfferAdidas.setText("50% off on every Item!! Visit your nearest Adidas showroom. HURRY!!");
	        tvOfferAdidas.setTextSize(20);
	        tvOfferAdidas.setVisibility(View.VISIBLE);
	        tvOfferAdidas.setTextColor(Color.RED);
	        tvOfferAdidas.setBackgroundColor(Color.BLACK);
		}
	};

	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		
		 requestWindowFeature(Window.FEATURE_NO_TITLE);
		    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
		                            WindowManager.LayoutParams.FLAG_FULLSCREEN);
		    
		    super.onCreate(savedInstanceState);
		    
		setContentView(R.layout.activity_main);
		
		// to make a notification
		mgr = (NotificationManager)this.getSystemService(Context.NOTIFICATION_SERVICE);
	       
			AdidasNote = new Notification(R.drawable.notification,"50% off on Adidas shoes. Hurry!!",System.currentTimeMillis());
			NikeNote = new Notification(R.drawable.notification,"45% off on Nike T-shirts. Hurry!!",System.currentTimeMillis());
	        
	        PendingIntent OpenNotificationActivity=PendingIntent.getActivity(this, 0,new Intent(this, MainActivity.class),0);
	        AdidasNote.setLatestEventInfo(this, "Adidas Offer!!!",
                    "50% off on Adidas shoes. Hurry !!",OpenNotificationActivity);
	        
	        NikeNote.setLatestEventInfo(this, "Nike Offer!!!",
                    "45% off on Nike T-shirts. Grab them. Hurry!",OpenNotificationActivity);
	        
		
		getSupportActionBar().hide();
		/*tvDistance1 = (TextView) findViewById(R.id.distance1);
		tvDistance2 = (TextView) findViewById(R.id.distance2);
		tvNearestBeacon = (TextView) findViewById(R.id.nearest);*/
		tvOfferNike = (TextView) findViewById(R.id.offerNike);
		tvOfferAdidas = (TextView) findViewById(R.id.offerAdidas);
		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		iv= (ImageView)findViewById(R.id.image);

		Intent bluetoothIntent = new Intent(
				BluetoothAdapter.ACTION_REQUEST_ENABLE);
		startActivityForResult(bluetoothIntent, 0);

		sensoroManager = SensoroManager.getInstance(getBaseContext());
		sensoroManager.setBackgroundBetweenScanPeriod(120000);
		sensoroManager.setBackgroundScanPeriod(30000);

		if (sensoroManager.isBluetoothEnabled()) {
			/**
			 * Enable cloud service (upload sensor data, including battery
			 * status, UMM, etc.)。Without setup, it keeps in closed status as
			 * default.
			 **/
			sensoroManager.setCloudServiceEnable(true);

			try {
				sensoroManager.startService();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		BeaconManagerListener beaconManagerListener = new BeaconManagerListener() {
		

			@Override
			public void onUpdateBeacon(
					ArrayList<com.sensoro.beacon.kit.Beacon> beacons) {
				// TODO Auto-generated method stub
				for (com.sensoro.beacon.kit.Beacon beacon : beacons) {
					if (beacon.getSerialNumber().equals("0117C5377507")) {
						
						distance1 = beacon.getAccuracy();
						beaconDistance1 = Double.toString(distance1);
						/*runOnUiThread(new Runnable() {

							@Override
							public void run() {

								tvDistance1.setText("Beacon 1 distance: "
										+ beaconDistance1);
							}
						});*/

						/*
						 * if (beacon.getMovingState() ==
						 * com.sensoro.beacon.kit.Beacon.MovingState.DISABLED){
						 * // Disable accelerometer } else if
						 * (beacon.getMovingState() ==
						 * com.sensoro.beacon.kit.Beacon.MovingState.STILL){ //
						 * Device is at static } else if
						 * (beacon.getMovingState() ==
						 * com.sensoro.beacon.kit.Beacon.MovingState.MOVING){ //
						 * Device is moving }
						 */
					}
					if (beacon.getSerialNumber().equals("0117C5382EAD")) {
						distance2 = beacon.getAccuracy();
						beaconDistance2 = Double.toString(distance2);
						/*runOnUiThread(new Runnable() {
							@Override
							public void run() {
								// TODO Auto-generated method stub
								tvDistance2.setText("Beacon 2 distance: "
										+ beaconDistance2);
							}
						});*/

					}
					if (distance1 > distance2) {
						
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								// TODO Auto-generated method stub
								/*tvNearestBeacon
										.setText("Beacon with ID 0117C5382EAD is nearest at a distance of "
												+ beaconDistance2 + "m");
								tvNearestBeacon.setTextSize(20);*/
								tvOfferNike.setVisibility(View.GONE);
								
								iv.setImageResource(R.drawable.adidas);
								mHandler.postDelayed(runnableAdidas, 10000L);
								
								//mHandler.removeCallbacks(runnableIdea);
							}
						});
					} else {
						
						runOnUiThread(new Runnable() {
							
							@Override
							public void run() {
								// TODO Auto-generated method stub
								/*tvNearestBeacon
										.setText("Beacon with ID 0117C5377507 is nearest at a distance of "
												+ beaconDistance1 + "m");
								tvNearestBeacon.setTextSize(20);*/
								
								tvOfferAdidas.setVisibility(View.GONE);
								iv.setImageResource(R.drawable.nike);
								mHandler.postDelayed(runnableNike, 10000L);
								
								//mHandler.removeCallbacks(runnableAirtel);
							}
						});
						
					}
				}

			}

			@Override
			public void onNewBeacon(com.sensoro.beacon.kit.Beacon beacon) {
				// TODO Auto-generated method stub
				/*
				 * if (beacon.getSerialNumber().equals("0117C5377507")){
				 * 
				 * }
				 */
			}

			@Override
			public void onGoneBeacon(com.sensoro.beacon.kit.Beacon beacon) {
				// TODO Auto-generated method stub

			}
		};

		sensoroManager.setBeaconManagerListener(beaconManagerListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();

		// noinspection SimplifiableIfStatement
		if (id == R.id.action_settings) {
			return true;
		}

		return super.onOptionsItemSelected(item);
	}
}
