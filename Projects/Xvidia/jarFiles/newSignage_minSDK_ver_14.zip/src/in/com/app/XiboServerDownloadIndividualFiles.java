package in.com.app;

import in.com.app.data.LogData;
import in.com.app.data.SignageData;
import in.com.app.domain.DisplayLayoutFile;
import in.com.app.domain.DisplayLayoutFiles;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;
import in.com.app.utility.Utility;
import in.com.app.wsdl.XMDS;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;


/**
 * This class is wrapper for a asyncTask that downloads individual files from server.
 * @author Ravi@Xvidia
 * @since version 1.0
 *
 */
public class XiboServerDownloadIndividualFiles extends
AsyncTask<DisplayLayoutFiles, Void, ArrayList<String>> implements IDisplayLayout {
	
AppMain appmainInstance = null;
boolean downloadFail = false;
	
XiboServerDownloadIndividualFiles(AppMain appmain){
		appmainInstance = appmain;
	}
	

	@Override
	protected ArrayList<String> doInBackground(DisplayLayoutFiles... params) {			
		try{
			DisplayLayoutFiles files = params[0];
			XMDS xmds = new XMDS(ClientConnectionConfig._SERVERURL);
			ArrayList<String> fileList = new ArrayList<String>();
			int totalCount = files.getFileList().size();
			int count = 0;
			for (DisplayLayoutFile file : files.getFileList()) {

				if (!file.getType().equalsIgnoreCase(_BLACKLIST_CATEGORY) ) {
					String fileID = file.getId();
					String fileType = file.getType();
					String fileName = file.getPath();
					if(!fileType.equals(_FILE_TYPE_LAYOUT)){
						fileList.add(fileName);
					}
					if(file.getSize()!= null){
					int fileSize = Integer.parseInt(file.getSize());
					byte[] bytesData = new byte[fileSize];
					int chunkSize = _CHUNK_SIZE_512_KB;  ///MAGIC NUMBER SIZE DEFINED IN THE XIBO SPECIFICATION 
					if(!Utility.IsFileExists(fileName)){
						if(!Utility.IsFileExistsInDownload(fileName)){
							if(fileType.equals(_FILE_TYPE_LAYOUT))
								fileSize=0;// PASS CHUNK SIZE AS 0 :: MANDATORY IF TYPE IS LAYOUT OR BLACKLIST
							if(fileSize <=chunkSize){
								//							PASS CHUNK SIZE AS FILE SIZE IF FILESIZE LESS THAN OR EQUAL TO CHUNKSIZE
								try{
									bytesData =( xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , 0, fileSize/*file size*/, ClientConnectionConfig._VERSION)).toBytes();
//									if(bytesData == null){
//										downloadFail = true;
//									}
								}catch (Exception e) {
//									downloadFail = true;
	//								e.printStackTrace();
								}
							}else{
		
								int startByte = 0;
								int reRequestCounter = fileSize / chunkSize;
								if(fileSize%chunkSize > 0 ){
									reRequestCounter++;
								}
								for(int i =0 ;i<reRequestCounter;i++){
									try{
										if (i + 1 == reRequestCounter) {
											chunkSize = fileSize % chunkSize;
										}
										byte[] temp = (xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , startByte, chunkSize,  ClientConnectionConfig._VERSION)).toBytes();		
		
										if(temp!=null){
											for(int byteCount = 0 ; byteCount < temp.length; byteCount++){
												bytesData[startByte++] = temp[byteCount];
											}
										}else{
											downloadFail = true;
											Log.d(getClass().getCanonicalName(),"temp null");
										}
										temp = null;	
									}catch (Exception e) {
										downloadFail = true;
	//									e.printStackTrace();
									}
								}
								if(bytesData.length != fileSize ){
									downloadFail = true;								
								}
								
								Log.i("Download file", "chunks size"+bytesData.length+" filesize "+fileSize);
							}
		
							//						String fileUniqueId = fileType+"_"+fileID;
		
							if(bytesData!=null && !downloadFail){
								//							if(fileSize < _CHUNK_SIZE_512_KB && !fileType.equalsIgnoreCase(_MEDIA)){
								//								SignageData.getInstance().addRawDataNode(fileUniqueId, fileName, fileType, bytesData, fileSize);
								//							}else{
								//								//								DataCacheManager.getInstance().saveResourceData(Integer.parseInt(fileID), bytesData);
								//								//DataCacheManager.getInstance().saveResourceData(fileUniqueId, bytesData);								
								//								saveFileToDisc( fileName,bytesData);
								//								SignageData.getInstance().addRawDataNode(fileUniqueId, fileName, fileType, fileSize);
								//
								//							}
								//								if(fileType.equalsIgnoreCase(_FILE_TYPE_LAYOUT)){
								//									String tempFileName = fileName+".txt";
								//									saveFileToDisc( tempFileName,bytesData);
								//								}else{							
								saveFileToDisc( fileName,bytesData);
								DataCacheManager.getInstance().saveMediaData(fileName);
								//								}
								//								SignageData.getInstance().addRawDataNode(fileUniqueId, fileName, fileType, fileSize);
								SignageData.getInstance().addRawDataNode(StateMachine.gi(appmainInstance).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
								count++;
									appmainInstance.downloadMessage = "Files downloaded "+count+" / "+totalCount;
									StateMachine.gi(appmainInstance).updateStatus( count,totalCount);
									
									//							}
		
								//							if(fileType.equals(_FILE_TYPE_LAYOUT))							{
								//								
								//								SignageData.getInstance().addRawDataNode(fileUniqueId, fileName, fileType, bytesData, fileSize);
								//								String temp1 = fileUniqueId + _DELEMETER_1+fileName + _DELEMETER_1+ fileType + _DELEMETER_1+ new String(bytesData, "UTF-8") +_DELEMETER_1+fileSize+_DELEMETER_2;	
								//								DataCacheManager.getInstance().saveSettingData(_KEY_XIBO_LAST_DISPLAY_LAYOUT, temp1);
								//							}
								//							saveFileToDisc( fileName,bytesData);
								//							SignageData.getInstance().addRawDataNode(fileUniqueId, fileName, fileType, fileSize);
								//							String temp = fileUniqueId + _DELEMETER_1+fileName + _DELEMETER_1+ fileType + _DELEMETER_1+ fileSize+_DELEMETER_2;
								//							mapDataStringToSave = mapDataStringToSave+temp;
		
							}
						
						}else{
							DataCacheManager.getInstance().saveMediaData(fileName);
							SignageData.getInstance().addRawDataNode(StateMachine.gi(appmainInstance).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
						}
					}else{
						DataCacheManager.getInstance().saveMediaData(fileName);
						SignageData.getInstance().addRawDataNode(StateMachine.gi(appmainInstance).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
						count++;
						appmainInstance.downloadMessage = "Files downloaded "+count+" / "+totalCount;
						StateMachine.gi(appmainInstance).updateStatus( count, totalCount);
					}
					
				}
				}
			}
			FileManager.setFileArrayListNottoDelete(fileList);
		}catch (Exception e) {
			downloadFail = true;
//			e.printStackTrace();
		}
		return null; 
	}



	//		String mapDataStringToSave = "";

//	/***
//	 * @deprecated
//	 * @param filename
//	 * @param byteData
//	 * @return
//	 * @throws IOException
//	 */
//	private String saveFileToDisc1(String filename, byte[] byteData) throws IOException{
//		String PATH = Environment.getExternalStorageDirectory()
//				+ "/download/";
//		//filename = filename.concat(".mp4");
//		File checkFile = new File(PATH, filename);
//		
//		try {
//			checkFile.delete();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		File file = new File(PATH);
//		file.mkdirs();
//		File outputFile = new File(file, filename);
//
//
//		FileOutputStream fos = new FileOutputStream(outputFile);
//
//		fos.write(byteData);
//		fos.close();
//
//		return PATH + filename;
//
//	}
//	
	private String saveFileToDisc(String filename, byte[] byteData) throws IOException{
//		String PATH = Environment.getExternalStorageDirectory()
//				+ "/download/";
		
		String PATH = Environment.getExternalStorageDirectory()
				+ AppState.DOWNLOAD_FOLDER;
		//filename = filename.concat(".mp4");
		File checkFile = new File(PATH, filename);

		try {
			checkFile.delete();
		} catch (Exception e) {
//			e.printStackTrace();
		}

		File file = new File(PATH);
		//if(file.isDirectory()){
			if(!file.exists())
				file.mkdirs();
		//}
		File outputFile = new File(file, filename);


		FileOutputStream fos = new FileOutputStream(outputFile);

		fos.write(byteData);
		fos.close();

		return PATH + filename;

	}

	@Override
	protected void onPostExecute(final ArrayList<String> data) {
		boolean nextStepFlag = false;
		if(SignageData.getInstance().getRawDataNode().size()>0){	
			//				DataCacheManager.getInstance().saveSettingData(_KEY_XIBO_LAST_DISPLAY_RESOURCE_MAP, mapDataStringToSave);
			nextStepFlag = true;
			//copy files from download to Display
			try {
				if(!downloadFail){
					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_TRUE);
				
					String destPath = Environment.getExternalStorageDirectory()
							+ AppState.DISPLAY_FOLDER;
					String sourcePath = Environment.getExternalStorageDirectory()
							+ AppState.DOWNLOAD_FOLDER;
					 File sourceLocation = new File (sourcePath);
					 File targetLocation = new File (destPath);
					 
					 
					 FileManager.copyDirectoryOneLocationToAnotherLocation(sourceLocation, targetLocation);
					 FileManager.deleteDir(sourceLocation);


					 String xml = DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML);
						DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
//						DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
						LogData.getInstance().setCurrentDisplayXml(AppMain.getAppMainContext(), xml);
					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML,"");
					appmainInstance.downloadFailed = false;
				}else{
					appmainInstance.downloadFailed = true;
					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
				}
			} catch (IOException e) {
				appmainInstance.downloadFailed = true;
				DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
			
			}
		}
		appmainInstance.stopProgress();
		StateMachine.gi(appmainInstance).initProcess(nextStepFlag, StateMachine.SHOWDISPLAY);	
//		new DeletFileTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void)null);
	}

//private class DeletFileTask extends AsyncTask<Void, Void, String> {
//		
//		public DeletFileTask() {
//			
//		}
//
//		@Override
//		protected String doInBackground(Void... params) {
//			try {
//				Utility.deleteLeastUsedFileOnLowMemory();
//				return null;
//			} catch (Exception e) {
//				return "";
////				e.printStackTrace();
//			}
//			
//		}
//		
//		@Override
//		protected void onPostExecute(final String data) {
//		}
//			
//	}

}