package in.com.app.background;

import in.com.app.AppMain;
import in.com.app.AppState;
import in.com.app.ClientConnectionConfig;
import in.com.app.FileManager;
import in.com.app.IDisplayLayout;
import in.com.app.SignageDisplay;
import in.com.app.data.LogData;
import in.com.app.data.SignageData;
import in.com.app.domain.DisplayLayoutFile;
import in.com.app.domain.DisplayLayoutFiles;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;
import in.com.app.updater.LogUtility;
import in.com.app.utility.Utility;
import in.com.app.wsdl.XMDS;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
/**
 * This class is wrapper for a asyncTask that downloads individualfiles from server in the background.
 * @author Ravi@Xvidia
 * @since version 1.0
 *
 */
public class XiboServerDownloadIndividualFilesDisplay extends
AsyncTask<DisplayLayoutFiles, Void, ArrayList<String>> implements IDisplayLayout {

	
	Context context = null;
	Activity activity = null;
	boolean downloadFail = false;
	
	XiboServerDownloadIndividualFilesDisplay(Context ctx, Activity act){
		context = ctx;
		activity = act;
	}


	@Override
	protected ArrayList<String> doInBackground(DisplayLayoutFiles... params) {			
		try{
			DisplayLayoutFiles files = params[0];
			XMDS xmds = new XMDS(ClientConnectionConfig._SERVERURL);

			ArrayList<String> fileList = new ArrayList<String>();
			for (DisplayLayoutFile file : files.getFileList()) {

				if (!file.getType().equalsIgnoreCase(_BLACKLIST_CATEGORY) ) {
					String fileID = file.getId();
					String fileType = file.getType();
					String fileName = file.getPath();
					fileList.add(fileName);
					if(fileType.equals(_FILE_TYPE_LAYOUT)){
						DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_NEW_LAYOUT, fileName);
					}
					int fileSize = Integer.parseInt(file.getSize());
					byte[] bytesData = new byte[fileSize];
					int chunkSize = _CHUNK_SIZE_512_KB;  ///MAGIC NUMBER SIZE DEFINED IN THE XIBO SPECIFICATION 
					if(!Utility.IsFileExists(fileName)){
						if(!Utility.IsFileExistsInDownload(fileName)){
							if(fileType.equals(_FILE_TYPE_LAYOUT))
								fileSize=0;// PASS CHUNK SIZE AS 0 :: MANDATORY IF TYPE IS LAYOUT OR BLACKLIST
							if(fileSize <=chunkSize){
								//							PASS CHUNK SIZE AS FILE SIZE IF FILESIZE LESS THAN OR EQUAL TO CHUNKSIZE
								try{
									bytesData =( xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , 0, fileSize/*file size*/, ClientConnectionConfig._VERSION)).toBytes();
									if(bytesData ==null){
										downloadFail = true;
									}
								}catch (Exception e) {
									downloadFail = true;
		//							e.printStackTrace();
								}
							}else{
		
								int startByte = 0;
								int reRequestCounter = fileSize / chunkSize;
								if(fileSize%chunkSize > 0 ){
									reRequestCounter++;
								}
								for(int i =0 ;i<reRequestCounter;i++){
									try{
										if (i + 1 == reRequestCounter) {
											chunkSize = fileSize % chunkSize;
										}
										byte[] temp = (xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , startByte, chunkSize, ClientConnectionConfig._VERSION)).toBytes();		
		
										if(temp!=null){
											for(int byteCount = 0 ; byteCount < temp.length; byteCount++){
												bytesData[startByte++] = temp[byteCount];
											}
										}else{
											downloadFail = true;
											Log.d(getClass().getName(),"TEMP NULL");
										}
										temp = null;	
									}catch (Exception e) {
										downloadFail = true;
										Log.d(getClass().getName(),e.getMessage());
									}
								}
								if(bytesData.length != fileSize ){
									downloadFail = true;								
								}
							}
		
							//						String fileUniqueId = fileType+"_"+fileID;
		
							if(bytesData!=null && !downloadFail){					
								saveFileToDisc(fileName,bytesData);
								DataCacheManager.getInstance().saveMediaData(fileName);
								SignageData.getInstance().addRawDataNode(StateMachineDisplay.gi(context,activity).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
		
							}
						}else{
							DataCacheManager.getInstance().saveMediaData(fileName);
							SignageData.getInstance().addRawDataNode(StateMachineDisplay.gi(context,activity).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
								
						}
					}else{
						DataCacheManager.getInstance().saveMediaData(fileName);
						SignageData.getInstance().addRawDataNode(StateMachineDisplay.gi(context,activity).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
						
					}
				}
			}
			FileManager.setFileArrayListNottoDelete(fileList);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null; 
	}



	private String saveFileToDisc(String filename, byte[] byteData) throws IOException{
		//		String PATH = Environment.getExternalStorageDirectory()
		//				+ "/download/";
		String PATH = Environment.getExternalStorageDirectory()+ AppState.DOWNLOAD_FOLDER;
		//filename = filename.concat(".mp4");
		File checkFile = new File(PATH, filename);

		try {
			checkFile.delete();
		} catch (Exception e) {
			e.printStackTrace();
		}

		File file = new File(PATH);
		//if(file.isDirectory()){
		if(!file.exists())
			file.mkdirs();
		//}
		File outputFile = new File(file, filename);


		FileOutputStream fos = new FileOutputStream(outputFile);

		fos.write(byteData);
		fos.close();

		return PATH + filename;

	}

	@Override
	protected void onPostExecute(final ArrayList<String> data) {

		CopyFileTask copyFileTask = new CopyFileTask();
		copyFileTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void)null);
//		boolean nextStepFlag = false;
//		if(SignageData.getInstance().getRawDataNode().size()>0){	
//			//				DataCacheManager.getInstance().saveSettingData(_KEY_XIBO_LAST_DISPLAY_RESOURCE_MAP, mapDataStringToSave);
//			nextStepFlag = true;
//			//copy files from download to Display
//			try {
//				if(!downloadFail){
//					String destPath = Environment.getExternalStorageDirectory()
//							+ AppState.DISPLAY_FOLDER;
//					String sourcePath = Environment.getExternalStorageDirectory()
//							+ AppState.DOWNLOAD_FOLDER;
//					File sourceLocation = new File (sourcePath);
//					File targetLocation = new File (destPath);
//					FileManager.copyDirectoryOneLocationToAnotherLocation(sourceLocation, targetLocation);
//					FileManager.deleteDir(sourceLocation);
//					String xml = DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML);
//					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
//					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML,"");
//					SignageDisplay.backGroundRefresh = true;
//					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_TRUE);
//					
//				}else{
//					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_FALSE);
//					
//				}
//			} catch (IOException e) {
//				DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_FALSE);			
////				e.printStackTrace();
//			}
//		}
//		StateMachineDisplay.gi(context, activity).initProcess(nextStepFlag, StateMachineDisplay.SHOWDISPLAY);		
	}
	
//private class DeletFileTask extends AsyncTask<Void, Void, String> {
//		
//		public DeletFileTask() {
//			
//		}
//
//		@Override
//		protected String doInBackground(Void... params) {
//			try {
//				Utility.deleteLeastUsedFileOnLowMemory();
//				return null;
//			} catch (Exception e) {
//				return "";
////				e.printStackTrace();
//			}
//			
//		}
//		
//		@Override
//		protected void onPostExecute(final String data) {
//		}
//			
//	}
	private class CopyFileTask extends AsyncTask<Void, Void, String> {
		
		public CopyFileTask() {
			
		}

		@Override
		protected String doInBackground(Void... params) {
			try {
				String destPath = Environment.getExternalStorageDirectory()
						+ AppState.DISPLAY_FOLDER;
				String sourcePath = Environment.getExternalStorageDirectory()
						+ AppState.DOWNLOAD_FOLDER;
				File sourceLocation = new File (sourcePath);
				File targetLocation = new File (destPath);
				FileManager.copyDirectoryOneLocationToAnotherLocation(sourceLocation, targetLocation);
				FileManager.deleteDir(sourceLocation);
				return null;
			} catch (IOException e) {
				return "";
//				e.printStackTrace();
			}catch (Exception e) {
				return "";
//				e.printStackTrace();
			}
			
		}
		
		@Override
		protected void onPostExecute(final String data) {
			boolean nextStepFlag = false;
			if(SignageData.getInstance().getRawDataNode().size()>0){	
				//				DataCacheManager.getInstance().saveSettingData(_KEY_XIBO_LAST_DISPLAY_RESOURCE_MAP, mapDataStringToSave);
				nextStepFlag = true;
				//copy files from download to Display
				try {

					if(data == null){
						if(!downloadFail){
	//						String destPath = Environment.getExternalStorageDirectory()
	//								+ AppState.DISPLAY_FOLDER;
	//						String sourcePath = Environment.getExternalStorageDirectory()
	//								+ AppState.DOWNLOAD_FOLDER;
	//						File sourceLocation = new File (sourcePath);
	//						File targetLocation = new File (destPath);
	//						FileManager.copyDirectoryOneLocationToAnotherLocation(sourceLocation, targetLocation);
	//						FileManager.deleteDir(sourceLocation);
//							String xml = DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML);
//							DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
//							DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML,"");
//							SignageDisplay.backGroundRefresh = true;
//							DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_TRUE);
//							
							String layoutStaring = LogUtility.getLayoutStringFromFile(DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_NEW_LAYOUT));
							LogData.getInstance().setCurrentLayoutXml(AppMain.getAppMainContext(), layoutStaring);
							String xml = DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML);
//							DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
							LogData.getInstance().setCurrentDisplayXml(AppMain.getAppMainContext(), xml);
							DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML,"");
							SignageDisplay.backGroundRefresh = true;
							DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_TRUE);
						
						}else{
							DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_FALSE);
							
						}

					}else{
						DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_FALSE);
						
					}
				} catch (Exception e) {
					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_BACKGROUND_FILE_DOWNLOAD_COMPLETE, FLAG_FALSE);			
//					e.printStackTrace();
				}
			}
			StateMachineDisplay.gi(context, activity).initProcess(nextStepFlag, StateMachineDisplay.SHOWDISPLAY);

//			new DeletFileTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void)null);
		}
		
	}



}