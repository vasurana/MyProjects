package in.com.app.updater;


import java.io.IOException;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import in.com.app.AppMain;
import in.com.app.IDisplayLayout;
import in.com.app.data.LogData;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;
import in.com.app.utility.NativeCommunicationHandler;
import in.com.app.utility.RequestData;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView.BufferType;
/**
 * This class extends {@link BroadcastReceiver} to update nework change information
 * @author Ravi@xvidia
 * @since Version 1.0
 */
public class NetworkChangeReceiver extends BroadcastReceiver {
 
    @Override
    public void onReceive(final Context context, final Intent intent) {
		 try{
			 SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS",Locale.ENGLISH);
				Date now = new Date();
		        String status = NetworkUtil.getConnectivityStatusString(context);
		        if(status.equalsIgnoreCase("Not connected to Internet")){
//		        	HeartBeatData.getInstance().setNeworkType(status);
		        	String  data =  "Time: "+formatter.format(now);
		        	DataCacheManager.getInstance().saveSettingData(IDisplayLayout._KEY_XVIDIA_STATE_NETWORK_OFF_TIME, data);
		        }else{
		        	String  data =  "Time: "+formatter.format(now);
		        	Log.d("HEARTBEAT NETWORK STATUS", ""+status);
//		        	HeartBeatData.getInstance().setNeworkType(status);
		        	DataCacheManager.getInstance().saveSettingData(IDisplayLayout._KEY_XVIDIA_STATE_NETWORK_ON_TIME, data);
		        	DataCacheManager.getInstance().saveSettingData(IDisplayLayout._KEY_XVIDIA_STATE_NETWORK_TYPE, status);
		        	
			        
		        }
		        boolean flag = LogData.getInstance().setNetworkType(context, status);
		        AppMain.connectionStatus.setText(status, BufferType.NORMAL);
		        try{
		        	if(flag){
		        		sendLogRequest(context,LogUtility.getInstance().getNetworkJson(context),LogUtility.getNewtorkLogUrl());
		        	}
//		        	if(LogUtility.checkNetwrk(context)){
////		        		sendHttpPostUpdateRequest(context);
//		        	}else{
////		        		Log.d(DEBUG_TAG, "No network.....");
//		        	}
		        }catch (Exception e) {
//			        e.printStackTrace();
//			        Log.e("Your App Name Here", "HttpUtils: " + e);
				}
		        //Toast.makeText(context, status, Toast.LENGTH_LONG).show();
		 }catch(Exception e){
			 
		 }
    }
    
    private void sendLogRequest(Context ctx, JSONObject jsonObject, String urlStr){
  	  try {
  		  if(LogUtility.checkNetwrk(ctx)){
  			  RequestData reqObj = new RequestData(urlStr, jsonObject);

  				Log.d("Request sending", ""+urlStr);
  				new NativeCommunicationHandler().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, reqObj);
//  				sendHttpPostLogRequest(ctx, jsonObject, urlStr);
  		  }
//  			} catch (IOException e) {
//  				e.printStackTrace();
  		}catch(Exception e){
  			
  		}
  	}
    /**
     * Post heartbeat update request to update heartbeat information
     * @param updateheartbeat url
     * @throws {@link IOException}
     */
  	private void sendHttpPostUpdateRequest(Context context)throws IOException {
     		//Log.d("Sending HEARTBEAT",""+url);
     		//final String returnVal = "";
//     		final String urlJson = LogUtility.getNewtorkLogUrl();
     		final JSONObject jsonObject = LogUtility.getInstance().getNetworkJson(context);
     		Log.d("Sending HEARTBEAT JSON",""+jsonObject.toString());
    		Thread thread = new Thread(new Runnable() {
    			@Override
    			public void run() {
    				try{
    					String urlJson = LogUtility.getNewtorkLogUrl();
    					 HttpPost httpPost = new HttpPost(urlJson);
    					   HttpClient client = new DefaultHttpClient();
    					   // Timeout Limit
    					   HttpConnectionParams.setConnectionTimeout(client.getParams(),LogData.TIME_OUT);
    					   StringEntity se = new StringEntity(jsonObject.toString());
    					   se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE,"application/json"));
    					   httpPost.setEntity(se);
    					   HttpResponse response = client.execute(httpPost);
//    					   String returnVal;
    					   int respCode = response.getStatusLine().getStatusCode();
    						if (response != null && respCode == HttpURLConnection.HTTP_OK )  {
//    							returnVal = EntityUtils.toString(response.getEntity());
//    							Log.i("result", returnVal);
    						}
    					   
     				//return returnVal;
     			} catch (Exception e) {
       			} 
				finally {

				}
			}
		});

		thread.start();
      }
}