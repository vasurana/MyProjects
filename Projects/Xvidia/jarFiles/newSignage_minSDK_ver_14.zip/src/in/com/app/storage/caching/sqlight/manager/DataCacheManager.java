package in.com.app.storage.caching.sqlight.manager;

import java.util.Vector;

import in.com.app.AppMain;
import in.com.app.data.MediaData;
import in.com.app.storage.caching.sqlight.CachDataSource;

/**
 * This is wrapper class of {@link CachDataSource} that  manages (update/delete) data in sqllite database
 * @author Ravi@xvidia
 *	@since version 1.0
 */
public class DataCacheManager {

	private static DataCacheManager Instance = new DataCacheManager();
	CachDataSource dataSource = CachDataSource.getInstance();

	/**
	 * This method maintains the singleton refrence the DataCacheManager
	 * @return single object of DataCacheManager
	 * @see {@link DataCacheManager}
	 * @since version 1.0
	 */
	public static DataCacheManager getInstance() {
		if (Instance != null)
			Instance = new DataCacheManager();
		return Instance;
	}

	private DataCacheManager() {
	}

	/**
	 * This method opens database
	 */
	public void open() {
		dataSource.open(AppMain.getAppMainContext());
	}
	
	/**
	 * Thismethod closes database
	 */
	public void close() {
		dataSource.close();
	}


	/**
	 * Thismethod saves setting data
	 * @param integer apiValue
	 * @param string apiData
	 * @return
	 */
	public boolean saveSettingData(int apiValue/*APIVAL MUST BE MORE THAN 0*/, String apiData) {
		boolean retVal = false;
		try{
			if(apiValue>0){
				dataSource.open(AppMain.getAppMainContext());
				dataSource.insertSettingData(apiValue, apiData);
				dataSource.close();
				retVal= true;		
			}else{
				return false;
			}
		}catch (Exception e) {
			retVal = false;
		}		
		return retVal;
	}

	/**
	 * This method returns setting data for a particular apiId
	 * @param apiValue
	 * @return string data
	 */
	public final String readSettingData(int apiValue) {
		dataSource.open(AppMain.getAppMainContext());
		String apiData = dataSource.getSettingData(apiValue);
		dataSource.close();
		if(apiData==null){
			apiData = "";
		}
		return apiData;
	}

	

	/**
	 * This method clears all setting database
	 */
	public final void clearSettingCache(){
		dataSource.open(AppMain.getAppMainContext());
		dataSource.removeSettingData();
		dataSource.close();
	}

	/**
	 * This method removes single data from database for a particular id
	 * @param apiId
	 * @return boolean value true or false
	 */
	public final boolean removeSettingDataByID(int apiValue){
		dataSource.open(AppMain.getAppMainContext());
		boolean retVal = dataSource.removeSettingDataByApiId(apiValue);
		dataSource.close();
		return retVal;
	}

	/**
	 * Thismethod saves setting data
	 * @param integer apiValue
	 * @param string apiData
	 * @return
	 */
	public boolean saveMediaData(String fileName) {
		boolean retVal = false;
		try{
				dataSource.open(AppMain.getAppMainContext());
				dataSource.insertMediaData(fileName);
				dataSource.close();
				retVal= true;		
			
		}catch (Exception e) {
			retVal = false;
		}		
		return retVal;
	}

	/**
	 * This method returns setting data for a particular apiId
	 * @param apiValue
	 * @return string data
	 */
	public final MediaData readMediaData(String filename) {
		dataSource.open(AppMain.getAppMainContext());
		MediaData apiData = dataSource.getMediaData(filename);
		dataSource.close();
//		if(apiData==null){
//			apiData = new MediaData();
//		}
		return apiData;
	}

	/**
	 * This method returns setting data for a particular apiId
	 * @param apiValue
	 * @return string data
	 */
	public final Vector<MediaData> getAllMediaData() {
		dataSource.open(AppMain.getAppMainContext());
		Vector<MediaData> mList = dataSource.getMediaList();
		dataSource.close();
//		if(apiData==null){
//			apiData = new MediaData();
//		}
		return mList;
	}

	/**
	 * This method clears all setting database
	 */
	public final void removeMediaData(){
		dataSource.open(AppMain.getAppMainContext());
		dataSource.removeMediaData();
		dataSource.close();
	}

	/**
	 * This method removes single data from database for a particular id
	 * @param apiId
	 * @return boolean value true or false
	 */
	public final boolean removeMediaByName(String fileName){
		dataSource.open(AppMain.getAppMainContext());
		boolean retVal = dataSource.removeMediaByName(fileName);
		dataSource.close();
		return retVal;
	}

	/**
	 * This method saves resource data
	 * @param apiValue
	 * @param apiData
	 * @return
	 * @deprecated
	 */
	public boolean saveResourceData(String apiValue/*APIVAL MUST BE MORE THAN 0*/, byte[] apiData) {
		boolean retVal = false;
		try{
			if(!apiValue.equals("")){
				dataSource.open(AppMain.getAppMainContext());
				dataSource.insertResourceData(apiValue, apiData);
				dataSource.close();
				retVal= true;		
			}else{
				return false;
			}
		}catch (Exception e) {
			retVal = false;
		}		
		return retVal;
	}

	/**
	 * This method returns resourcedata for a particular id
	 * @param apiValue
	 * @return
	 * @throws NullPointerException
	 * @deprecated
	 */
	public final byte[] readResourceData(String apiValue) throws NullPointerException{
		dataSource.open(AppMain.getAppMainContext());
		byte[] apiData = dataSource.getResourceData(apiValue);
		dataSource.close();		
		if(apiData==null){
			throw new NullPointerException();
		}
		return apiData;
	}

	

	/**
	 * This method clears resource data
	 * @deprecated
	 */
	public final void clearResourceCache(){
		dataSource.open(AppMain.getAppMainContext());
		dataSource.removeResourceData();
		dataSource.close();
	}

	/**
	 * This method removes resource data for a particular id
	 * @param apiValue
	 * @return
	 * @deprecated
	 */
	public final boolean removeResourceDataByID(String apiValue){
		dataSource.open(AppMain.getAppMainContext());
		boolean retVal = dataSource.removeResourceDataByApiId(apiValue);
		dataSource.close();
		return retVal;
	}
	
	/**
	 * This method removes all resurce data
	 * @return
	 * 
	 */
	public final boolean removeResourceDataAll(){
		dataSource.open(AppMain.getAppMainContext());
		boolean retVal = dataSource.removeResourceData();
		dataSource.close();
		return retVal;
	}




}
