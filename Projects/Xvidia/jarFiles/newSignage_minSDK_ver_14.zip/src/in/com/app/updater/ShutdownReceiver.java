package in.com.app.updater;

import in.com.app.IDisplayLayout;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * This class extends {@link BroadcastReceiver} to update shutdown and boot time
 * @author Ravi@xvidia
 * @since Version 1.0
 */
public class ShutdownReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
    	String action = intent.getAction();
    	SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
		Date now = new Date();
		if(action.equals(Intent.ACTION_BOOT_COMPLETED))
        {
			String  data =  "Time: "+formatter.format(now);
//			DataCacheManager.getInstance().saveSettingData(IDisplayLayout._KEY_XVIDIA_STATE_POWER_ON_TIME, data);
	    }else if(action.equals(Intent.ACTION_SHUTDOWN))
        {
        	String  data =  "Time: "+formatter.format(now);
//    		DataCacheManager.getInstance().saveSettingData(IDisplayLayout._KEY_XVIDIA_STATE_POWER_OFF_TIME, data);
        }else if(action.equals(Intent.ACTION_POWER_CONNECTED))
        {
			String  data =  "Time: "+formatter.format(now);
//			DataCacheManager.getInstance().saveSettingData(IDisplayLayout._KEY_XVIDIA_STATE_POWER_ON_TIME, data);
	    }else if(action.equals(Intent.ACTION_POWER_DISCONNECTED))
        {
        	String  data =  "Time: "+formatter.format(now);
//    		DataCacheManager.getInstance().saveSettingData(IDisplayLayout._KEY_XVIDIA_STATE_POWER_OFF_TIME, data);
        }
    }

}