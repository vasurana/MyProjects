package in.com.app;

import org.apache.commons.logging.Log;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import in.com.app.data.LogData;
import in.com.app.data.SignageData;
import in.com.app.domain.DisplayLayoutFile;
import in.com.app.domain.DisplayLayoutFiles;
import in.com.app.domain.DisplayLayoutSchedule;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;
import in.com.app.utility.Utility;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Toast;

/**
 * This is Class that changes state of processes
 * @author Ravi@xvidia
 * @since version 1.0
 */
public class StateMachine implements IDisplayLayout{

	final static int REGISTER = 0;
	final static int GETFILE = 1;
	final static int GETINDIVIDUALFILE = 2;
	final static int GETSCHEDULE = 3;
	final static int SHOWDISPLAY = 4;
	final static int OFFLINE = 5;
	
	final static int STATEMACHINE_CALL_APPMAIN = 0;
	final static int STATEMACHINE_CALL_DISPLAYSIGNAGE = 1;
	
	public DisplayLayoutFiles receivedXiboFiles = null;
	AppMain appmainInstance = null;
	
	static StateMachine instance = null;
	
	public static StateMachine gi(AppMain appmain){
		if(instance == null){
			instance =  new StateMachine(appmain);
		}
		return instance;
	}
	
	
	private StateMachine(){
		
	}
	
	private StateMachine(AppMain appmain){
		appmainInstance = appmain;
	}
	public void updateStatus( final int count, final int totalCount){
		try{
			String msg;//= appmainInstance.getResources().getString(R.string.process_text);
			msg = "Files downloading "+count+" / "+totalCount;
			AppMain.textViewInfo.setText(msg);
			AppMain.textViewInfo.setVisibility(View.VISIBLE);
			AppMain.progressBar.setMax(totalCount);
			AppMain.progressBar.setProgress(count);
			AppMain.progressBar.setVisibility(View.VISIBLE);
			Toast t = Toast.makeText(appmainInstance, msg, 3000);
			t.show();
		}catch(Exception e){
			
		}
	}
	/**
	 * This method switches between process
	 * @param boolean value to process next Request
	 * @param processId
	 */
	public void initProcess(final boolean nextRequest, final int processId){
		appmainInstance.stopProgress();
		
		if(!displayingContentInOffileMode && processId == OFFLINE){
//				Toast.makeText(appmainInstance, "offline mode.......", 5000).show();
//			String xml = LogData.getInstance().getCurrentDisplayLayout(AppMain.getAppMainContext());
			String xml = LogData.getInstance().getCurrentLayoutXml(AppMain.getAppMainContext());
			
			if(xml!=null && !xml.equalsIgnoreCase("") && !xml.equalsIgnoreCase(LogData.STR_UNKNOWN)){
				String  currentFile = DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_STATE_SCHEDULE_CURRENTFILE);
				SignageData.getInstance().setDefaultLayout(currentFile);
				SignageData.getInstance().setCurrentLayout(currentFile);
				displayContentInOfflineMode();
			}else{
//					Toast t = Toast.makeText(appmainInstance, "please check your internet connection", 5000);
//					t.show();
					AppMain.textViewInfo.setText( "please check your internet connection");
					AppMain.textViewInfo.setTextColor(appmainInstance.getResources().getColor(R.color.red_color));
					AppMain.textViewInfo.setVisibility(View.VISIBLE);
					initProcess(nextRequest,processId);
				}
		}else if(!displayingContentInOffileMode ){
			if(!checkNetwrk()){
//				Toast.makeText(appmainInstance, "offline mode.......", 5000).show();
				String xml = LogData.getInstance().getCurrentLayoutXml(AppMain.getAppMainContext());
				
				if(xml!=null && !xml.equalsIgnoreCase("") && !xml.equalsIgnoreCase(LogData.STR_UNKNOWN)){
					displayContentInOfflineMode();
				}else{
//					Toast t = Toast.makeText(appmainInstance, "please check your internet connection", 5000);
//					t.show();
					AppMain.textViewInfo.setText( "please check your internet connection NO OFFF");
					AppMain.textViewInfo.setTextColor(appmainInstance.getResources().getColor(R.color.red_color));
					AppMain.textViewInfo.setVisibility(View.VISIBLE);
					initProcess(nextRequest,processId);
//					return;
				}
			}
		}
		if(!nextRequest && processId == GETSCHEDULE){
			AppMain.textViewInfo.setText(R.string.register_complete);
			AppMain.textViewInfo.setTextColor(appmainInstance.getResources().getColor(R.color.buttonBackground));
			AppMain.textViewInfo.setVisibility(View.VISIBLE);
			new XiboServerConnectionManager(appmainInstance).execute();
			return;
		}else if(!nextRequest){
			return;
		}
		if(checkNetwrk()|| processId == SHOWDISPLAY){
			AppMain.textViewInfo.setText(R.string.process_text);
		switch (processId) {
			case REGISTER:
//				appmainInstance.showProgressMessage("registering");
				AppMain.textViewInfo.setVisibility(View.VISIBLE);
				Toast.makeText(appmainInstance, "registering", 500).show();
				new XiboServerConnectionManager(appmainInstance).execute();
				break;
			case GETSCHEDULE:
	//			appmainInstance.showProgressMessage("downloading schedule");
	//			AppMain.textViewInfo.setVisibility(View.VISIBLE);
				AppMain.textViewInfo.setVisibility(View.VISIBLE);
				Toast.makeText(appmainInstance, "downloading schedule", 500).show();
				new DisplayLayoutServerGetSchedule(appmainInstance).execute("");
				break;
			case GETFILE:
	//			appmainInstance.showProgressMessage("downloading file");
				AppMain.textViewInfo.setVisibility(View.VISIBLE);
//				Toast.makeText(appmainInstance, "downloading file", 1000).show();
				new XiboServerGetFiles(appmainInstance).execute();
				break;
			case GETINDIVIDUALFILE:
	//			appmainInstance.showProgressMessage("downloading");
				String msg= appmainInstance.getResources().getString(R.string.process_text);
				if(receivedXiboFiles != null && receivedXiboFiles.getFileList().size()>0){
					msg = "Files downloading "+"1 / "+(receivedXiboFiles.getFileList().size());
					AppMain.progressBar.setMax(receivedXiboFiles.getFileList().size());
					AppMain.progressBar.setProgress(1);
				}
				AppMain.textViewInfo.setText(msg);
				AppMain.textViewInfo.setTextColor(appmainInstance.getResources().getColor(R.color.buttonBackground));
				AppMain.textViewInfo.setVisibility(View.VISIBLE);
				AppMain.progressBar.setVisibility(View.VISIBLE);
//				Toast.makeText(appmainInstance, "downloading file", Toast.LENGTH_LONG).show();
				new XiboServerDownloadIndividualFiles(appmainInstance).execute(receivedXiboFiles);
				break;		
			case SHOWDISPLAY:
				AppMain.textViewInfo.setVisibility(View.GONE);
	//			appmainInstance.stopProgress();
				boolean individualFileSuccess = Utility.checkBooleanState(DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE));
				if(individualFileSuccess){
					displayingContentInOffileMode = false;
					Intent i = new Intent(appmainInstance, SignageDisplay.class);			
					appmainInstance.startActivity(i);
					appmainInstance.finish();

					DeleteFileTask deleteFileTask = new DeleteFileTask();
					deleteFileTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void)null);
				}else if(checkNetwrk()){
					initProcess(true, GETSCHEDULE);
				}else{
					AppMain.textViewInfo.setText("please check your internet connection");
					AppMain.textViewInfo.setTextColor(appmainInstance.getResources().getColor(R.color.red_color));
					AppMain.textViewInfo.setVisibility(View.VISIBLE);
					AppMain.progressBar.setVisibility(View.GONE);
//					Toast t = Toast.makeText(appmainInstance, "please check your internet connection", 5000);
//					t.show();
				}
				break;
			}
		}else{
			AppMain.textViewInfo.setText("please check your internet connection");
			AppMain.textViewInfo.setTextColor(appmainInstance.getResources().getColor(R.color.red_color));
			AppMain.textViewInfo.setVisibility(View.VISIBLE);
			AppMain.progressBar.setVisibility(View.GONE);
//			AppMain.textViewInfo.setVisibility(View.GONE);
//			Toast t = Toast.makeText(appmainInstance, "please check your internet connection", 5000);
//			t.show();
			return;
		}

	}
	
	
	public static boolean displayingContentInOffileMode = false;
	
	/**
	 * This method sends data to {@link SignageDisplay} to display layoutif it exists
	 */
	void displayContentInOfflineMode(){
		boolean regSuccess = Utility.checkBooleanState(DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_STATE_REG_COMPLETE));
		boolean scheduleSuccess = Utility.checkBooleanState(DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_STATE_SCHEDULE_COMPLETE));
		boolean fileSuccess = Utility.checkBooleanState(DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_STATE_FILE_COMPLETE));
		boolean individualFileSuccess = Utility.checkBooleanState(DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE));
		if(regSuccess && scheduleSuccess && fileSuccess && individualFileSuccess){
			displayingContentInOffileMode = true;
			ClientConnectionConfig.LAST_REQUEST_DATA = LogData.getInstance().getCurrentDisplayLayout(AppMain.getAppMainContext());
//			ClientConnectionConfig.LAST_REQUEST_DATA = DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML);
//			Toast.makeText(appmainInstance, "offline LAST_REQUEST_DATA "+ClientConnectionConfig.LAST_REQUEST_DATA, 5000).show();
			
			
			if(!ClientConnectionConfig.LAST_REQUEST_DATA.equals("") && !ClientConnectionConfig.LAST_REQUEST_DATA.equals(LogData.STR_UNKNOWN)){
				if(fillResourceMapIfOffline(ClientConnectionConfig.LAST_REQUEST_DATA)){
					initProcess(true, SHOWDISPLAY);
				}else{
					if(checkNetwrk()){
						initProcess(true, REGISTER);
					}else{
						Toast t = Toast.makeText(appmainInstance, "please check your internet connection", 5000);
						t.show();
						return;
					}
				}
			}else{
				if(checkNetwrk()){
					initProcess(true, REGISTER);
				}else{
					Toast t = Toast.makeText(appmainInstance, "please check your internet connection", 5000);
					t.show();
					return;
				}
			}
		}else{
			displayingContentInOffileMode = true;
			if(checkNetwrk()){
				initProcess(true, REGISTER);
			}else{
				Toast t = Toast.makeText(appmainInstance, "please check your internet connection", 5000);
				t.show();
				return;
			}
		}
	}
	
	/**
	 * This method check network connectivity status
	 * @return boolean value for network status
	 */
	boolean checkNetwrk(){
		boolean nwFlag = false;
		try{		
			ConnectivityManager connMgr = (ConnectivityManager) appmainInstance.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				nwFlag = true;
			}
		}catch (Exception e) {
			//e.printStackTrace();
		}

		return nwFlag;
	}
	
	
	/**
	 * This method add a row to Signage data of the files to be displayed
	 * @param data
	 * @return
	 */
	boolean fillResourceMapIfOffline(String data){
		boolean retVal = false;
		Serializer serializer = new Persister();
		DisplayLayoutFiles lstFiles = null;

		try {
			lstFiles = serializer.read(DisplayLayoutFiles.class, data);
			for (DisplayLayoutFile file : lstFiles.getFileList()) {

				if (!file.getType().equalsIgnoreCase(_BLACKLIST_CATEGORY) ) {
					String fileID = file.getId();
					String fileType = file.getType();
					String fileName = file.getPath();
					int fileSize= 0;
					if(file.getSize()!=null){
						fileSize = Integer.parseInt(file.getSize());
					}

//					if(fileType.equalsIgnoreCase(_FILE_TYPE_LAYOUT)){
//						fileName = fileName+".txt";
//					}

					SignageData.getInstance().addRawDataNode(getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
					retVal = true;
				}
			}
		} catch (Exception e) {
			retVal = false;
//			e.printStackTrace();
		}
		return retVal;
	}

	
	private class DeleteFileTask extends AsyncTask<Void, Void, Void> {
		
		public DeleteFileTask() {
			
		}

		@Override
		protected Void doInBackground(Void... params) {
			try {
//				String destPath = Environment.getExternalStorageDirectory()
//						+ AppState.DISPLAY_FOLDER;
//				File targetLocation = new File (destPath);
				Utility.deleteLeastUsedFileOnLowMemory();
//				FileManager.deleteDirIfFileNotInList(targetLocation);
			} catch (Exception e) {
//				e.printStackTrace();
			}
			
			return null;
		}
	}
	/**
	 * This method returns unique file id
	 * @param fileType
	 * @param fileID
	 * @return
	 */
	String getUniqueFileId(String fileType, String fileID ){
		return fileType+"_"+fileID;
	}

}
