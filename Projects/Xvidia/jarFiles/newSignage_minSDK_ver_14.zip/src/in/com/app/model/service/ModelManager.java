package in.com.app.model.service;

/**
 * This class is wrapper that manages maintains state of json response model
 * @author Ravi@Xvidia
 *	@version 1.0
 *	@since version 1.0
 */

public class ModelManager {
	private static ModelManager obj =null;
	private UpdateRequestModel updateModelObj = null;
	
	/**
	 * This method maintains the singleton refrence the {@link ModelManager}
	 * @return single object of {@link ModelManager}
	 * @see {@link ModelManager}
	 * @since version 1.0
	 */
	private ModelManager(){}
	public static ModelManager getInstance(){
		if(obj == null){
			obj = new ModelManager();			
		}
		return obj;
	}

	
	/**
	 * This method sets parsed reference for the response in {@link UpdateRequestModel}
	 * @param String value for the response recieved
	 * @return boolean value  true if successfully parsed
	 * @see {@link UpdateRequestModel}
	 * @since version 1.0
	 */	
	public boolean setUpdateServiceRequestModel(String response){
		boolean retval = false;
		try {
			updateModelObj = new UpdateRequestModel(response);
			retval = true;
		} catch (Exception e) {
			retval = false;
		}		
		return retval;
	}

	/**
	 * This method returns single refrence to {@link UpdateRequestModel}
	 * @return {@link UpdateRequestModel} object refrence
	 */
	public UpdateRequestModel getUpdateServiceRequestModel(){
		return updateModelObj;
	}

}
