package in.com.app.model.base;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

/**
 * This class is a base class for parsing JSON response from server
 * @author Ravi@xvidia
 * @since version 1.0
 *
 */
public class AppResponse extends ModelDataBase  {
	
	final String RESPONSE_KEY_OP_STATUS = "opStatus";
	final String RESPONSE_KEY_ERROR_MESSAGE = "errorMessage";

	protected Hashtable<String, JSONObject> mapJSONObject = new Hashtable<String, JSONObject>();
	protected Hashtable<String, JSONArray> mapJSONArray = new Hashtable<String, JSONArray>();
	protected Hashtable<String, String> mapJSONString = new Hashtable<String, String>();
	
	protected String opStatus = null;
	protected String errorMessage = null;
//	protected String messageDescription = null;
//	protected String currentDate = null;
//	protected String cacheDataInMins = null;
//	protected String refNo = null;





	protected AppResponse() {
	}

	@SuppressWarnings("unchecked")
	public AppResponse(String response) throws JSONException {
		Log.d(getClass().getName(),"");
		JSONObject root = null;
		try{
		 root = new JSONObject(response);
//		 root = new JSONObj
	}catch (Exception e) {
			e.printStackTrace();
	}
		//the following is sent/receive in json
//		JSONObject mAppData = root.getJSONObject("mAppData");
//		JSONObject businessOutput = mAppData.getJSONObject("businessOutput");
//		JSONObject xiboData = null;
//		JSONObject businessOutput = null;
//		//if(conf.CONNECTION_RESPONSE_ACCEPT_TYPE == conf.ACCEPT_XML ){
//			xiboData = root.getJSONObject("xiboData");
//			businessOutput = xiboData.getJSONObject("businessOutput");
//		}else{
//		 businessOutput = root.getJSONObject("businessOutput");
//		}
		if(root != null){
			Iterator<String> it = root.keys();
			if (it == null) {
				return;
			}
			String name = null;
			while (it.hasNext()) {
				name = (String) it.next();
				Object o = root.get(name);
				if (o instanceof JSONObject) {
					mapJSONObject.put(name, (JSONObject) o);
				} else if (o instanceof JSONArray) {
					mapJSONArray.put(name, (JSONArray) o);
				} else if (o instanceof String) {
					mapJSONString.put(name, (String) o);
				}
			}
		}
	}

	
	
	public AppResponse(Hashtable<String, Object> response) throws JSONException {		
		Enumeration<Object>enumKey = response.elements();
		String name = null;
		while (enumKey.hasMoreElements()) {
			name = (String) enumKey.nextElement();
			Object o = response.get(name);
			if (o instanceof JSONObject) {
				mapJSONObject.put(name, (JSONObject) o);                    
			} else if (o instanceof JSONArray) {
				mapJSONArray.put(name, (JSONArray) o);
			} else if (o instanceof String) {
				mapJSONString.put(name, (String) o);
			}
				
		}
		
	}

	public int getOpStatus() {
		int opstatusVal  =  0;
		try{
			opstatusVal = Integer.parseInt(opStatus);
			}
		catch (Exception e) {
		}
		return opstatusVal;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	
//	public String getMessageDescription(){	
//		if(messageDescription == null)
//			return INVALID_MESSAGEDESC;
//		else
//		return messageDescription;		
//	}
	
//	public String getCurrentDate(){
//		return currentDate;
//	}
//
//	public int getCacheDataInMins(){
//		int cacheDataMins  =  0;
//		try{
//			cacheDataMins = Integer.parseInt(cacheDataInMins);
//			}
//		catch (Exception e) {
//		}
//		return cacheDataMins;
//	}
//	
//	public String getCacheDataInMinsString(){
//		return cacheDataInMins;
//	}
//	
//	public long getCacheDataInMilliSec(){
//		long cacheDataMins  =  0;
//		try{
//			cacheDataMins = 60000*(Long.parseLong(cacheDataInMins));
//			}
//		catch (Exception e) {
//		}
//		return cacheDataMins;
//	}
//	
//	public String getrefNo(){
//		return refNo;		
//	}
//	
	
//	protected String validateString(String value){
//		if(value!=null)
//			return value;
//		else
//			return "";
//	}

}