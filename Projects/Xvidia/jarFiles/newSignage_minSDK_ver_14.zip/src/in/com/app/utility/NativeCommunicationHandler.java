package in.com.app.utility;

import in.com.app.data.LogData;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;

import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.util.Log;



//Uses AsyncTask to create a task away from the main UI thread. This task takes a 
// URL string and uses it to create an Http Connection. Once the connection
// has been established, the AsyncTask downloads the contents of the server which is
// sent back to Listener by the AsyncTask's onPostExecute method.

public class NativeCommunicationHandler extends AsyncTask<RequestData, Void, String> {	
	HttpPost httpPost;
	int conTimeOut;
	int reqCount = 0;
	boolean reqSuccessFull = false;
	JSONObject reqJson = null;
	String url;


	public NativeCommunicationHandler() {
		conTimeOut = 60000;//180000;
	}

	@SuppressWarnings("finally")
	@Override
	protected String doInBackground(RequestData... paramReq) {
		RequestData objReq = paramReq[0]; 
		String retVal = "";
		try {
//			reqJson = objReq.getRequestJson();
//			url = objReq.getRequestUrl();
			
					retVal = sendHttpPostRequest(objReq.getRequestUrl(), objReq.getRequestJson());
					reqCount++;
					
		} catch (IOException e) {
			Log.d("result", e.getMessage());
		} catch (Exception e) {
			Log.d("result", e.getMessage());
		}
		finally{
			return retVal;        	
		}
	}


	// onPostExecute displays the results of the AsyncTask.
	@Override
	protected void onPostExecute(String result) {
	}


	//SEND POST REQUEST TO SERVER 
	//Input URL, XML, HEADERLIST
	//Output response from server 
	@SuppressWarnings("finally")
	private String sendHttpPostRequest(String url, JSONObject jsonObject)throws IOException {
//		System.out.println("Sending Request.."+url+"\n"+jsonObject);
		//System.out.println("Request XML.."+xml);
		String returnVal = "";
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, conTimeOut);

		//   		HttpClient httpClient = new DefaultHttpClient(); 
		DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);        
		httpPost = new HttpPost(url);   		
		HttpResponse response = null;
		try {   			
			   // Timeout Limit
			   HttpConnectionParams.setConnectionTimeout(httpClient.getParams(),
			     LogData.TIME_OUT);
			   StringEntity se = new StringEntity(jsonObject.toString());
			   se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE,"application/json"));
			   httpPost.setEntity(se);
			   response = httpClient.execute(httpPost);
//			   String returnVal;
			   int respCode = response.getStatusLine().getStatusCode();
				if (response != null && respCode == HttpURLConnection.HTTP_OK )  {
					returnVal = EntityUtils.toString(response.getEntity());
//					Log.i("result", returnVal);
				}
		}
		catch (UnsupportedEncodingException e) {
			Log.d("Response Received",e.getMessage());
		}
		catch (IOException e) {
			Log.d("Response Received",e.getMessage());
		}
		catch (ParseException e) {
			Log.d("Response Received",e.getMessage());
		}
		catch (Exception e) {
			Log.d("Response Received",e.getMessage());
		}		
		finally{
			Log.i("Response Received",returnVal);
			if(httpPost!=null){
				//httpPost.
			}
			return returnVal;	
		}
	}

	


//	//SEND GET REQUEST TO SERVER 
//	//Input URL, XML, HEADERLIST
//	//Output response from server 
//	@SuppressWarnings("finally")
//	private String sendHttpGetRequest(String url)throws IOException {
//		System.out.println("Sending Request.."+url);
//		Log.d("Sending Request","");
//		String returnVal = "";
//
//		HttpParams httpParameters = new BasicHttpParams();
//		HttpConnectionParams.setConnectionTimeout(httpParameters, conTimeOut);
//
//		//     		HttpClient httpClient = new DefaultHttpClient(); 
//		DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);        
//		httpGet = new HttpGet(url);   		
//		HttpResponse response = null;
//		//     		setHeaders(headerTable);
//		try {
//			//     			System.out.println("URL::"+url);
//			//     			System.out.println("XML::"+xml);		
//			response = httpClient.execute(httpGet);//, localContext);
//			if(response != null){
//				int respCode = response.getStatusLine().getStatusCode();
//				if (response != null && respCode == HttpURLConnection.HTTP_OK) {
//					returnVal = EntityUtils.toString(response.getEntity());
//					Log.i("result", returnVal);
//				}
//			}
//		} 
//
//		catch (Exception e) {
//			e.printStackTrace();
//			Log.e("Your App Name Here", "HttpUtils: " + e);
//			//     			returnVal = new AppResponseXML().getConnectionErrorXML();
//		}
//		finally{
//			Log.i("Response Received",returnVal);
//			if(httpGet!=null){
//
//			}
//			return returnVal;	
//		}
//	}



//	// Given a URL, establishes an HttpUrlConnection and retrieves
//	// the web page content as a InputStream, which it returns as
//	// a string.
//	@SuppressWarnings("unused")
//	private String sendURLRequest(String myurl, String xml) throws IOException {
//		InputStream is = null;
//		// Only display the first 500 characters of the retrieved
//		// web page content.
//		int len = 500;
//
//		try {
//			URL url = new URL(myurl);
//			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//			conn.setReadTimeout(10000 /* milliseconds */);
//			conn.setConnectTimeout(15000 /* milliseconds */);
//			conn.setRequestMethod("POST");
//			conn.setDoInput(true);
//			// Starts the query
//			conn.connect();
//			int response = conn.getResponseCode();
//			Log.d("DEBUG", "The response is: " + response);
//			is = conn.getInputStream();
//
//			// Convert the InputStream into a string
//			String contentAsString = readIt(is, len);
//			return contentAsString;
//
//			// Makes sure that the InputStream is closed after the app is
//			// finished using it.
//		} finally {
//			if (is != null) {
//				is.close();
//			} 
//		}
//	}
//
//
//	public String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
//		Reader reader = null;
//		reader = new InputStreamReader(stream, "UTF-8");        
//		char[] buffer = new char[len];
//		reader.read(buffer);
//		return new String(buffer);
//	}
//
//
//	/**
//	 * @param hdr
//	 */
//	void setHeaders(Hashtable<String, String> hdr){
//		if(hdr==null)
//			return;
//		try{
//			Enumeration<String > enumHdr = hdr.keys();
//			while(enumHdr.hasMoreElements()){		 
//				String key = ""+enumHdr.nextElement();
//				String val = hdr.get(key);
//				if(conReqType == REQ_POST){
//					System.out.println("POST REQ HDR:"+" Key="+key+" Val="+val);
//					httpPost.setHeader(key, val);	
//
//				}else if(conReqType == REQ_GET){
//					httpGet.setHeader(key, val);				 
//				}
//			}	 
//		}catch (Exception e) {
//			
//		}
//	}

	
	@SuppressWarnings("serial")
	class CommunicationError extends Exception{
		int errorCd;
		public CommunicationError(int errorCode) {
			errorCd = errorCode;
		}

		public int getErrorCode(){
			return errorCd;		
		}

	}
}

