package in.com.app.model.base;

import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * This class is a helper class to parse JSON data from {@link Hashtable}
 * @author Ravi@xvidia
 * @since version 1.0
 *
 */
public class ModelHelper {
	
	/**
	 * This method gets {@link JSONObject} from a {@link Hashtable} for a key
	 * @param {@link Hashtable} of {@link JSONObject} to be checked
	 * @param string variable key to get its value
	 * @return {@link JSONObject} from the {@link Hashtable}
	 */
	public static JSONObject getJSONObjectFromHashtable(Hashtable<String, JSONObject> mapJSONObject , String key){
		JSONObject jObj = null;
		try{
			jObj = (JSONObject) mapJSONObject.get(key);
		}catch (Exception e) {
			// TODO: handle exception
		}
		return jObj;
	}
	
	/**
	 * This method gets {@link JSONArray} from a {@link Hashtable} for a key
	 * @param {@link Hashtable} of {@link JSONArray} to be checked
	 * @param string variable key to get its value
	 * @return {@link JSONArray} from the {@link Hashtable}
	 */
	public static JSONArray getJSONArrayFromHashtable(Hashtable<String, JSONArray> mapJSONObject , String key){
		JSONArray jArray = null;
		try{
			jArray = (JSONArray) mapJSONObject.get(key);
		}catch (Exception e) {
			// TODO: handle exception
		}
		return jArray;
	}
	
	/**
	 * This method gets String value from a {@link Hashtable} for a key
	 * @param {@link Hashtable} to be checked
	 * @param string variable key to get its value
	 * @return String value from the {@link Hashtable}
	 */
	public static String getStringFromHashtable(Hashtable<String, String> mapJSONObject , String key){
		String strObj = null;
		try{
			strObj = (String) mapJSONObject.get(key);
			strObj= strObj.trim();
		}catch (Exception e) {
			// TODO: handle exception
		}
		return strObj;
	}
	
	/**
	 * This method gets String value from a {@link JSONObject}  for a key
	 * @param {@link JSONObject} to be checked
	 * @param string variable key to get its value
	 * @return String value from the JSONObject
	 */
	public static String getJSONValue(JSONObject jObj , String key){
		String strObj = "";
		try{
			if (jObj.has(key)) {
				strObj = (String) jObj.get(key);
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return strObj;
	}
	
	/**
	 * This method gets JSONObject from a {@link JSONObject} 
	 * @param {@link JSONObject} to be checked
	 * @param string variable key for JSONObject
	 * @return {@link JSONObject} from the JSONObject
	 */
	@SuppressWarnings("finally")
	public static JSONObject getJSONObjectFromJSONObject(JSONObject jObj, String key){
		JSONObject j_obj = null;
		try {
			j_obj = jObj.getJSONObject(key);
		} catch (Exception e) {
			// TODO: handle exception
			j_obj = null;
		}finally{
			return j_obj;
		}
	}
	
	/**
	 * This method gets JSONArray from a {@link JSONObject} 
	 * @param {@link JSONObject} to be checked
	 * @param string variable key for json array
	 * @return {@link JSONArray} from the JSONObject
	 */
	@SuppressWarnings("finally")
	public static JSONArray getJSONArrayFromJSONObject(JSONObject jObj, String key){
		JSONArray j_array = null;
		try {
			j_array = jObj.getJSONArray(key);
		} catch (Exception e) {
			// TODO: handle exception
			j_array = null;
		}finally{
			return j_array;
		}
	}
	
	/**
	 * This method checks is a key is present in the {@link JSONObject} 
	 * @param {@link JSONObject} to be checked
	 * @param string variable key
	 * @return boolean value false if key is not in json object
	 */
	@SuppressWarnings("finally")
	public static boolean checkNodeInJson(JSONObject jObj, String key){
		boolean ret = false;
		try{
			jObj.getString(key);
			ret = true;
		}catch (Exception e) {
			ret = false;			
		}
		finally{
			return ret;
		}
	}
	
	/**
	 * This method checks is a key is present in the  {@link JSONObject} of JSONObject
	 * @param {@link JSONObject} to be checked
	 * @param string variable key
	 * @return boolean value false if key is not in json object
	 */
	public boolean checkIfNodeJSONObject(JSONObject jObj, String key){
		boolean retVal = false;// return false if key s not a json object
		try {
			Object jsonObj = jObj.getJSONObject(key);
			if(jsonObj instanceof JSONObject){
				retVal = true;
			}
		} catch (JSONException e) {
			retVal = false;
		}
		return retVal;

	}

	/**
	 * This method checks is a key is present in the {@link JSONArray} of {@link JSONObject} 
	 * @param {@link JSONObject} to be checked
	 * @param string variable key
	 * @return boolean value false if key is not a json array
	 */
	public boolean checkIfNodeJSONArrayJSONObject (JSONObject jObj, String key){
		boolean retVal = false;// return false if key s not a json array
		try {
			Object jsonArrayObj = jObj.getJSONArray(key);
			if(jsonArrayObj instanceof JSONArray){
				retVal = true;
			}
		} catch (JSONException e) {
			retVal = false;
		}
		return retVal;

	}

}
