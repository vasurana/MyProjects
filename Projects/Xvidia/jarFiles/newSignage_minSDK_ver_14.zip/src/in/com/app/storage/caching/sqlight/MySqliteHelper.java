package in.com.app.storage.caching.sqlight;

import in.com.app.AppMain;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
/**
 *  This is a SQLite Helper class
 * @author Ravi@Xvidia Technologies
 * @version 1.0
  *
 */
public class MySqliteHelper extends SQLiteOpenHelper {

	// public static variables for caching image table
	public static final String TABLE_NAME_SETTING = "XIBO_SETTING_TABLE";
	public static final String TABLE_NAME_MEDIA_TABLE = "MEDIA_INFO_TABLE";
	public static final String TABLE_NAME_RESOURCE_TABLE = "XIBO_RESOURCE_TABLE";
	public static final String COLUMN_CACHING_API_ID = "apiCachingId";
	public static final String COLUMN_CACHING_DATA = "cachingData";
	public static final String COLUMN_MEDIA_NAME = "mediaName";
	public static final String COLUMN_MEDIA_DATE = "mediaDate";
	public static final String COLUMN_MEDIA_DOWNLOAD_COUNT = "downloadCount";
//	public static final String COLUMN_CACHING_SPECIAL_COMMENT = "specialComment";

	private static final String DATABASE_NAME = "xibosql.db";
	private static final int DATABASE_VERSION =3;

	/* Caching table create sql statement */

	private static final String TABLE_CREATE_CACHING = "create table "
			+ TABLE_NAME_SETTING + "(" + COLUMN_CACHING_API_ID
			+ " integer primary key autoincrement, " + COLUMN_CACHING_DATA
			+ " text );";
	
	private static final String TABLE_CREATE_MEDIA_INFO = "create table "
			+ TABLE_NAME_MEDIA_TABLE + "(" + COLUMN_MEDIA_NAME
			+ " text primary key, " + COLUMN_MEDIA_DOWNLOAD_COUNT
			+ " text, " + COLUMN_MEDIA_DATE
			+ " integer);";
	private static final String TABLE_CREATE_RESOURCE = "create table "
			+ TABLE_NAME_RESOURCE_TABLE + "(" + COLUMN_CACHING_API_ID
			+ " text primary key , " + COLUMN_CACHING_DATA
			+ " blob );";
	
	

	private static MySqliteHelper INSTANCE = new MySqliteHelper(
			AppMain.getAppMainContext());

	public static MySqliteHelper getInstance() {
		if (INSTANCE != null)
			INSTANCE = new MySqliteHelper(AppMain.getAppMainContext());
		return INSTANCE;
	}

	private MySqliteHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase database) {
		database.execSQL(TABLE_CREATE_CACHING);
		database.execSQL(TABLE_CREATE_RESOURCE);
		database.execSQL(TABLE_CREATE_MEDIA_INFO);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//		Log.w(MySqliteHelper.class.getName(),
//				"Upgrading database from version " + oldVersion + " to "
//						+ newVersion + ", which will destroy all old data");
		try{
			switch(oldVersion) {
		   case 1:
			   db.execSQL(TABLE_CREATE_MEDIA_INFO);
		   case 2:
			   db.execSQL("ALTER TABLE "+TABLE_NAME_MEDIA_TABLE+ " ADD COLUMN "+COLUMN_MEDIA_DATE+" TEXT");
			   
		   }
		} catch (SQLException e) {
			e.printStackTrace();
		}
//		db.execSQL("DROP TABLE IF EXISTS " + TABLE_CREATE_CACHING);
//		db.execSQL("DROP TABLE IF EXISTS " + TABLE_CREATE_RESOURCE);
//		onCreate(db);
		
	}
}
