package in.com.app.updater;

import in.com.app.data.LogData;
import in.com.app.utility.NativeCommunicationHandler;
import in.com.app.utility.RequestData;

import java.io.IOException;
import java.net.HttpURLConnection;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
/**
 * This class extends {@link BroadcastReceiver} to send hearbeat info to server
 * @author Ravi@xvidia
 * @since Version 1.0
 */
public class HeartBeatReceiver extends BroadcastReceiver {
    private static final String DEBUG_TAG = "HeartBeatReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
    	Log.d(DEBUG_TAG, "HEARTBEAT");
//        String updateUrl ="http://192.168.1.5:9000/log";
//        String updateUrl ="http://54.251.108.112:9000/log";
        try{
        	LogUtility.getInstance().getHeartBeatJSON(context);
//        	sendLogRequest(context,LogUtility.getInstance().getHeartBeatJSON(context),LogUtility.getHearbeatUrl());
//        	if(LogUtility.checkNetwrk(context)){
//        		sendHttpPostUpdateRequest(context);
//        	}else{
////        		Log.d(DEBUG_TAG, "No network.....");
//        	}
        }catch (Exception e) {
//	        e.printStackTrace();
//	        Log.e("Your App Name Here", "HttpUtils: " + e);
		}
        //String updateStr = "{\"xiboData\":{\"businessOutput\":{\"updateVersion\": \"0.1\",\"updateUrl\": \"http://122.160.145.138:9090/mc/getsmartclient?filePath=android/5.1.4/1.0.0.1/MyVodafone.apk\",\"opStatus\":\"0\",\"errorMessage\":\"An updated version is available\"}}}";
    	//String updateStr = "<?xml version='1.0' encoding='UTF-8' standalone='yes'><xiboData><businessOutput><updateAvailable>true</updateAvailable><opStatus>0</opStatus><errorMessage>An updated version is available</errorMessage></businessOutput></xiboData>";
 
    }
    
    private void sendLogRequest(Context ctx, JSONObject jsonObject, String urlStr){
	  try {
		  if(LogUtility.checkNetwrk(ctx)){
			  RequestData reqObj = new RequestData(urlStr, jsonObject);

				Log.d("Request sending", ""+urlStr);
				new NativeCommunicationHandler().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, reqObj);
//				sendHttpPostLogRequest(ctx, jsonObject, urlStr);
		  }
//			} catch (IOException e) {
//				e.printStackTrace();
		}catch(Exception e){
			
		}
	}

//    /**
//     * This method checks if networkis connected or not
//     * @param context
//     * @return true is connected to internet else false
//     */
//      boolean checkNetwrk(Context context){
//		boolean nwFlag = false;
//		try{		
//			ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
//			NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
//			if (networkInfo != null && networkInfo.isConnected()) {
//				nwFlag = true;
//			}
//		}catch (Exception e) {
//			//e.printStackTrace();
//		}
//
//		return nwFlag;
//	}
    /**
     * Post heartbeat update request to update heartbeat information
     * @param updateheartbeat url
     * @throws {@link IOException}
     */
  	private void sendHttpPostUpdateRequest(Context context)throws IOException {
     		Log.d("Sending HEARTBEAT","Request");
     		//final String returnVal = "";
//     		final String urlJson = url;
     		final JSONObject jsonObject = LogUtility.getInstance().getHeartBeatJSON(context);
     		Log.d("Sending HEARTBEAT JSON",""+jsonObject.toString());
    		Thread thread = new Thread(new Runnable() {
    			@Override
    			public void run() {
    				try{
    					 HttpPost httpPost = new HttpPost(LogUtility.getHearbeatUrl());
    					   HttpClient client = new DefaultHttpClient();
    					   // Timeout Limit
    					   HttpConnectionParams.setConnectionTimeout(client.getParams(),
    					     LogData.TIME_OUT);
    					   StringEntity se = new StringEntity(jsonObject.toString());
    					   se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE,"application/json"));
    					   httpPost.setEntity(se);
    					   HttpResponse response = client.execute(httpPost);
//    					   String returnVal;
    					   int respCode = response.getStatusLine().getStatusCode();
    						if (response != null && respCode == HttpURLConnection.HTTP_OK )  {
//    							returnVal = EntityUtils.toString(response.getEntity());
//    							Log.i("result", returnVal);
    						}
    					   
     				//return returnVal;
     			} catch (Exception e) {
       			} 
				finally {

				}
			}
		});

		thread.start();
      }
//    
}
