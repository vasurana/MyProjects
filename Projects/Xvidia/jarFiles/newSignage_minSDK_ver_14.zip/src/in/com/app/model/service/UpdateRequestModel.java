package in.com.app.model.service;

import in.com.app.AppMain;
import in.com.app.IDisplayLayout;
import in.com.app.data.LogData;
import in.com.app.model.base.AppResponse;
import in.com.app.model.base.ModelHelper;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;

/**
 * This class parse update response from server. Its base class is {@link AppResponse}
 * @author Ravi@Xvidia
 *	@version 1.0
 *	@since version 1.0
 */

public class UpdateRequestModel extends AppResponse{
	final String tag_updateVersion = "version";
	final String tag_updateUrl  = "path";
	String updateVersion = "";
	String updateUrl = "";
	public UpdateRequestModel(String response) throws Exception{
		super(response);
		try{
			updateVersion =  ModelHelper.getStringFromHashtable(mapJSONString, tag_updateVersion);
			updateUrl =  ModelHelper.getStringFromHashtable(mapJSONString, tag_updateUrl);
		}catch(Exception e){
			
		}
	}

	/**
	 * This method checks the current installed version of app with available version available on server.
	 * @return boolean value true if update is available
	 *	@since version 1.0
	 */
	public boolean getUpdateAvailable(){
		String verStr = validateString(updateVersion);
		String verClientStr =LogData.getInstance().getAppVersion(AppMain.getAppMainContext());// DataCacheManager.getInstance().readSettingData(IDisplayLayout._KEY_XVIDIA_CLIENT_VERSION);
		
		boolean retFlag = false;
		try{
			if(!verStr.equalsIgnoreCase("")){
				Double ver= Double.parseDouble(verStr);			
				Double verClient= Double.parseDouble(verClientStr);
//				Double verClientAlarm= Double.parseDouble(AlarmReceiver.appVersion);
//				if(verClient >= verClientAlarm){
					if(ver>verClient){
						//AlarmReceiver.appVersion = verStr;
						retFlag = true;
					}
//				}
					
			}
		}catch(Exception e){
			
		}
		return retFlag;
//		return true;
	}

	/**
	 * This method returns url for the apk to be downloaded
	 * @return string url path to the updated apk
	 *	@since version 1.0
	 */
	public String  getUpdateUrl(){
		return validateString(updateUrl);
		
	}
	
	/**
	 * This method returns version of apk on server
	 * @return string value for version
	 *	@since version 1.0
	 */
	public String  getUpdateVersion(){
		return validateString(updateVersion);
		
	}
}
