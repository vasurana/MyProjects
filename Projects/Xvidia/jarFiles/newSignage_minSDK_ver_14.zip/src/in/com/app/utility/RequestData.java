package in.com.app.utility;

import org.json.JSONObject;


public class RequestData {//implements IAPIConstants{
private JSONObject reqJson;
private String requestUrl;

public RequestData(String url, JSONObject jsonObject) {
	
	setRequestUrl(url);
	setRequestJson(jsonObject);
}

String getRequestUrl() {
	return requestUrl;
}

void setRequestUrl(String requestUrl) {
	this.requestUrl = requestUrl;
}


void setRequestJson(JSONObject jsonObject) {
	this.reqJson = jsonObject;
}

public JSONObject getRequestJson() {
	return reqJson;
}


}
