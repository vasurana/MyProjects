package in.com.app.storage.caching.sqlight;

import java.util.Date;
import java.util.Vector;

import in.com.app.data.MediaData;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

/**
 * This is a class of that  manages (update/delete) data in sqllite database
 * @author Ravi@xvidia
 *	@since version 1.0
 */
public class CachDataSource {
	private SQLiteDatabase database;
	private MySqliteHelper dbHelper;

	private Vector<MediaData> mediaList;
	private static CachDataSource INSTANCE = new CachDataSource();

	public static CachDataSource getInstance() {
		if (INSTANCE != null)
			INSTANCE = new CachDataSource();
		return INSTANCE;
	}

	private CachDataSource() {
		dbHelper = MySqliteHelper.getInstance();
	}
	/**
	 * This method opens database
	 */
	public void open(Context c) throws SQLException {
		try {
			if (database==null)				
				database = dbHelper.getWritableDatabase();
			else if(!database.isOpen()){
				database = dbHelper.getWritableDatabase();
			}
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * This method closes database
	 */
	public void close() {
//		Log.d("CachedDataSource", "Closed");
		dbHelper.close();
		database.close();
	}

	/**
	 * Thismethod saves setting data in setting databse
	 * @param int value set apiValue
	 * @param string apiData
	 * @return
	 */
	public void insertSettingData(int rowId, String data) {
		ContentValues values = new ContentValues();
		if (rowId > 0){
			values.put(MySqliteHelper.COLUMN_CACHING_API_ID, rowId);
			values.put(MySqliteHelper.COLUMN_CACHING_DATA, data);
		}
		if (rowId > 0){
			database.delete(MySqliteHelper.TABLE_NAME_SETTING, MySqliteHelper.COLUMN_CACHING_API_ID + "=" + rowId, null);
		}
		database.insert(MySqliteHelper.TABLE_NAME_SETTING, null, values);
	}
	/**
	 * This method returns setting data for a particular apiId
	 * @param apiValue
	 * @return string data
	 */
	public String getSettingData(int apiId) {
		String data = null;
		Cursor cursor = database.query(MySqliteHelper.TABLE_NAME_SETTING, null,
				MySqliteHelper.COLUMN_CACHING_API_ID + "=" + apiId, null, null,
				null, null);

		if (cursor != null && cursor.getCount() > 0) {
			cursor.moveToFirst();
			data = cursor.getString(cursor
						.getColumnIndex(MySqliteHelper.COLUMN_CACHING_DATA));
			} else {
				removeSettingDataByApiId(apiId);
			}
		

		cursor.close();
		return data;
	}
	/**
	 * This method clears all setting database
	 */
	public void removeSettingData() {
		database.delete(MySqliteHelper.TABLE_NAME_SETTING, null, null);
	}

	/**
	 * This method removes single data from database for a particular id
	 * @param apiId
	 * @return boolean value true or false
	 */
	public boolean removeSettingDataByApiId(int apiId) {
		int deletedRows = database.delete(MySqliteHelper.TABLE_NAME_SETTING,
				MySqliteHelper.COLUMN_CACHING_API_ID + "=" + apiId, null);
		if(deletedRows>0)
			return true;
		else
			return false;
	}
/////////////////////////////////
	///////////////////////
	//////////////
	
	/**
	 * Thismethod saves setting data in setting databse
	 * @param int value set apiValue
	 * @param string apiData
	 * @return
	 */
	public void insertMediaData(String fileName) {
		int count = 1;
		Date currentDate = new Date();
		long dateLong = currentDate.getTime();
			MediaData data = getMediaData(fileName);
			if (data!= null){
				count = data.getMediaDownloadCount();
				count = count+1;
				updateMediaData(fileName, count,dateLong);
			}else{
				ContentValues values = new ContentValues();
				values.put(MySqliteHelper.COLUMN_MEDIA_NAME, fileName);
				values.put(MySqliteHelper.COLUMN_MEDIA_DOWNLOAD_COUNT,count);
				values.put(MySqliteHelper.COLUMN_MEDIA_DATE,dateLong);
				database.insert(MySqliteHelper.TABLE_NAME_MEDIA_TABLE, null, values);			
			}
	}
	public void updateMediaData(String fileName, int count, long dateLong) {
		try {
			ContentValues values = new ContentValues();
			values.put(MySqliteHelper.COLUMN_MEDIA_NAME,fileName);
			values.put(MySqliteHelper.COLUMN_MEDIA_DOWNLOAD_COUNT,count);
			values.put(MySqliteHelper.COLUMN_MEDIA_DATE,dateLong);
				database.update(MySqliteHelper.TABLE_NAME_MEDIA_TABLE, values,
						MySqliteHelper.COLUMN_MEDIA_NAME + "=?",
						new String[] { fileName });
		
		} catch (Exception e) {

		}
	}
	
	public void getAllMediaData() {
		try {
			Cursor cursor = database.query(MySqliteHelper.TABLE_NAME_MEDIA_TABLE, null, null, null, null,
					null, MySqliteHelper.COLUMN_MEDIA_DOWNLOAD_COUNT+" DESC, "+MySqliteHelper.COLUMN_MEDIA_DATE+" DESC");
			MediaData mediaObj = null;
			Vector<MediaData> mList = new Vector<MediaData>();
			if (cursor!= null && cursor.getCount() != 0) {

				cursor.moveToPosition(0);
				for (int i = cursor.getPosition(); i < cursor.getCount(); i++) {
					cursor.moveToPosition(i);
					mediaObj = new MediaData();
					mediaObj.setMediaName(cursor.getString(cursor.getColumnIndex(MySqliteHelper.COLUMN_MEDIA_NAME)));
					mediaObj.setDownloadCount(cursor.getInt(cursor.getColumnIndex(MySqliteHelper.COLUMN_MEDIA_DOWNLOAD_COUNT)));
					mediaObj.setDownloadDate(cursor.getLong(cursor.getColumnIndex(MySqliteHelper.COLUMN_MEDIA_DATE)));
					mList.addElement(mediaObj);
				}
				setMediaList(mList);
				cursor.close();
			} else {
				setMediaList(new Vector<MediaData>());
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public Vector<MediaData> getMediaList() {
		getAllMediaData();
		return mediaList;
	}

	private void setMediaList(Vector<MediaData> mList) {
		this.mediaList = mList;
	}
	/**
	 * This method clears all setting database
	 */
	public void removeMediaData() {
		database.delete(MySqliteHelper.TABLE_NAME_MEDIA_TABLE, null, null);
	}

	/**
	 * This method removes single data from database for a particular id
	 * @param apiId
	 * @return boolean value true or false
	 */
	public boolean removeMediaByName(String filename) {
		int deletedRows = database.delete(MySqliteHelper.TABLE_NAME_MEDIA_TABLE,
				MySqliteHelper.COLUMN_MEDIA_NAME + "=" + filename, null);
		if(deletedRows>0)
			return true;
		else
			return false;
	}
	
	
	/**
	 * This method returns setting data for a particular apiId
	 * @param apiValue
	 * @return string data
	 */
	public MediaData getMediaData(String fileName) {

		MediaData obj = null;
		try{
		Cursor cursor = database.query(MySqliteHelper.TABLE_NAME_MEDIA_TABLE, null,
				MySqliteHelper.COLUMN_MEDIA_NAME + "='" + fileName+"'", null, null,
				null, null);
		if (cursor != null && cursor.getCount() > 0) {
			cursor.moveToFirst();
			obj = new MediaData();
			obj.setMediaName(cursor.getString(cursor.getColumnIndex(MySqliteHelper.COLUMN_MEDIA_NAME)));
			obj.setDownloadCount(cursor.getInt(cursor.getColumnIndex(MySqliteHelper.COLUMN_MEDIA_DOWNLOAD_COUNT)));
			obj.setDownloadDate(cursor.getLong(cursor.getColumnIndex(MySqliteHelper.COLUMN_MEDIA_DATE)));
			} else {
				removeMediaByName(fileName);
			}
		

		cursor.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return obj;
	}

	
	
	



////////////////////
	/////////////////////
	/////////////////
	
	
	/**
	 * This method saves resource data in databse table
	 * @param apiValue
	 * @param apiData
	 * @return
	 * @deprecated
	 */	
	public void insertResourceData(String rowId, byte[] bytes) {
		ContentValues values = new ContentValues();
		if (!rowId.equals("")){
			values.put(MySqliteHelper.COLUMN_CACHING_API_ID, rowId);
			values.put(MySqliteHelper.COLUMN_CACHING_DATA, bytes);
			database.delete(MySqliteHelper.TABLE_NAME_RESOURCE_TABLE, MySqliteHelper.COLUMN_CACHING_API_ID + "='" + rowId+"'", null);
		}
		 database.insert(MySqliteHelper.TABLE_NAME_RESOURCE_TABLE, null, values);
	}	
	
	/**
	 * This method clears resource data
	 *
	 */
	public boolean removeResourceData() {
		if(database.delete(MySqliteHelper.TABLE_NAME_RESOURCE_TABLE, null, null)>0){
			return true;
		}else
			return false;
	}

	/**
	 * This method removes resource data for a particular id
	 * @param apiValue
	 * @return
	 * @deprecated
	 */
	public boolean removeResourceDataByApiId(String apiId) {
		int deletedRows = database.delete(MySqliteHelper.TABLE_NAME_RESOURCE_TABLE,
				MySqliteHelper.COLUMN_CACHING_API_ID + "='" + apiId+"'", null);
		if(deletedRows>0)
			return true;
		else
			return false;
	}
	
	
	/**
	 * This method returns resourcedata for a particular id
	 * @param apiValue
	 * @return
	 * @deprecated
	 */
	public byte[] getResourceData(String apiId) {
		byte[] data = null;
		Cursor cursor = database.query(MySqliteHelper.TABLE_NAME_RESOURCE_TABLE, null,
				MySqliteHelper.COLUMN_CACHING_API_ID + "='" + apiId+"'", null, null,
				null, null);

		if (cursor != null && cursor.getCount() > 0) {
			cursor.moveToFirst();
			data = cursor.getBlob(cursor
						.getColumnIndex(MySqliteHelper.COLUMN_CACHING_DATA));
			} else {
				removeResourceDataByApiId(apiId);
			}
		

		cursor.close();
		return data;
	}



}
