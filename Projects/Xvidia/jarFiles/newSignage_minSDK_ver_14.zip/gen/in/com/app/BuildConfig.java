/** Automatically generated file. DO NOT MODIFY */
package in.com.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}