package in.com.app.data;

import in.com.app.domain.DisplayLayout;

import java.util.Date;
import java.util.List;


public class RefreshMediaData {
	String duration = null;
	long timestamp ;
	DisplayLayout.Region region=null;
//	List<DisplayLayout.Media> medialist=null;
	int mediaCount = 0;
	
	
	public int getMediaCount() {
		return mediaCount;
	}

	public void setMediaCount(int mediaCount) {
		this.mediaCount = mediaCount;
	}

//	public List<DisplayLayout.Media> getMedialist() {
//		return medialist;
//	}
//
//	public void setMedialist(List<DisplayLayout.Media> medialist) {
//		this.medialist = medialist;
//	}

	public String getDuration() {
		return getValidatedString(duration);
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public long getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public DisplayLayout.Region getRegion() {
		return region;
	}

	public void setRegion(DisplayLayout.Region region) {
		this.region = region;
	}

	//	static Vector<MusicData> musicList;
	private String getValidatedString(String valStr){
		if(valStr == null){
			return "";
		}else{
			return valStr.trim();
		}
	}
	
	
	
}
