package in.com.app.model;


public interface IAPIConstants{	
//	public final int API_KEY_REGISTRATION = 0;
//	public final int API_KEY_VIEW_USER_PROFILE = 1;
	public final int API_KEY_MEDIA_TIME =1;
	public final int API_KEY_MEDIA_TIME_OFFLINE = 2;
	public final int API_KEY_LAYOUT_TIME = 3;
	public final int API_KEY_LAYOUT_TIME_OFFLINE = 4;
	public final int API_KEY_ONOFF_BOX = 5;
	public final int API_KEY_ONOFF_APP = 6;
	public final int API_KEY_ONOFF_SCREEN = 7;
	public final int API_KEY_ONOFF_BOX_OFFLINE = 8;
	public final int API_KEY_ONOFF_APP_OFFLINE = 9;
	public final int API_KEY_ONOFF_SCREEN_OFFLINE = 10;
	public final int INVALID_OPSTATUS = -999;
	public final String INVALID_MESSAGEDESC = "INVALID_MESSAGE_DESC";
	
	
	
	/////////SHARED PREF FLAGS//
	public final String  TERM_COND_FLAG = "tc" ;
	public final String WELCOME_SCREEN_DIPLAYED = "welcome";
	public final String FLG_FALSE = "false";
	public final String FLG_TRUE = "true";

	
	/////SERVER RESPONSE ERROR CODES///
//	public final int SUCCESS                    = 0 ;
//	public final int INVALID_REQUEST            = 1;
//	public final int INTERNAL_SERVER_ERROR      =2;
//	public final int INTEGRATION_COMPONENT_ERROR=3;
//	public final int REGISTRATION_ERROR         =4;
//	public final int INVALID_OPERATOR_MSISDN    =5;
//	public final int ALREADY_REGISTERED_MSISDN  =6;
//	public final int USER_ID_ALREADY_REGISTERED =7;
//	public final int TIME_OUT                   =8;
//	public final int NO_DATA_AVAILABLE          =9;
//	public final int REQUEST_BLOCKED            =10;
//	public final int MSISDN_NOT_PRESENT         =11;
//	public final int REGISTRATION_PARTIAL       =12;
//	public final int DEVICE_CLIENT_ID_EXPIRED   =13;
//	public final int API_SECRET_EXPIRED			=14;
//	public final int FORCE_LOGOUT				=15;
//	public final int FLUSH_CACHE				=16;
//	public final int MANDATORY_PARAMETER_MISSING=17;
//	public final int MANDATORY_PARAMETER_INCORRECT=18;
//	public final int UNKNOWN_ERROR				=19;
//	public final int ALGO_NOT_SUPPORTED			=20;
//	public final int AUTHENTICATION_ERROR = 22;
	
	
	
	/////APP LEVEL ERROR CODES
//	public final int APP_MSG_SERVER_CON_FAIL = -111;
//	public final int APP_MSG_COMMUNICATION_ERROR = -112; //if 500 received from server
	
	
   
	
}
