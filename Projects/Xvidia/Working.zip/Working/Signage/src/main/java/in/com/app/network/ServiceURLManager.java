package in.com.app.network;


import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Vector;

import in.com.app.model.IAPIConstants;


public class ServiceURLManager implements IAPIConstants {



	//	Vector<Object> v1 = new Vector<Object>(3);
	//	v1.add("http://172.16.0.6:8081/mcare/selfcare/v2/service/updateTask");
	//	v1.add(getBody());
	//	v1.add(API_KEY_VIEW_USER_PROFILE);
	final String base_URL = "http://54.251.255.172:9999";//"http://192.168.1.104:9999";//
	final int vectorSize =4;

	public String getURL(int SERVICE_API){
		String service = "";
		switch (SERVICE_API) {
		case API_KEY_MEDIA_TIME:
			service = base_URL+ ServiceURL.API_KEY_MEDIA_TIME;
			break;
		case API_KEY_MEDIA_TIME_OFFLINE:
			service = base_URL+ ServiceURL.API_KEY_MEDIA_TIME_OFFLINE;
			break;
		case API_KEY_LAYOUT_TIME:
			service = base_URL+ ServiceURL.API_KEY_LAYOUT_TIME;
			break;
		case API_KEY_LAYOUT_TIME_OFFLINE:
			service = base_URL+ ServiceURL.API_KEY_LAYOUT_TIME_OFFLINE;
			break;
		case API_KEY_ONOFF_SCREEN:
			service = base_URL+ ServiceURL.API_KEY_ONOFF_SCREEN;
			break;
		case API_KEY_ONOFF_APP:
			service =base_URL+ ServiceURL.API_KEY_ONOFF_APP;
			break;
		case API_KEY_ONOFF_BOX:
			service =base_URL+ ServiceURL.API_KEY_ONOFF_BOX;
			break;
		case API_KEY_ONOFF_SCREEN_OFFLINE:
			service = base_URL+ ServiceURL.API_KEY_ONOFF_SCREEN_OFFLINE;
			break;
		case API_KEY_ONOFF_APP_OFFLINE:
			service =base_URL+ ServiceURL.API_KEY_ONOFF_APP_OFFLINE;
			break;
		case API_KEY_ONOFF_BOX_OFFLINE:
			service =base_URL+ ServiceURL.API_KEY_ONOFF_BOX_OFFLINE;
			break;
		}	
		return service;	
	}


	final String checkNullValue(String str){
		if(str == null)
			str = "";
		return str;
	}


	
	public Vector<Object> getAPIGetMdiaTimeRequest(JSONObject jObject){
		int serviceID = API_KEY_MEDIA_TIME;
		Vector<Object> v = new Vector<Object>(vectorSize);
		v.add(getURL(serviceID));
		v.add(jObject);	
		v.add(serviceID);
		v.add(1);
		return v;	
	}
	
	public Vector<Object> getAPIGetLayoutTimeRequest(JSONObject jObject){
		int serviceID = API_KEY_LAYOUT_TIME;
		Vector<Object> v = new Vector<Object>(vectorSize);
		v.add(getURL(serviceID));	
		v.add(jObject);	
		v.add(serviceID);
		v.add(1);
		return v;	
	}
	public Vector<Object> getAPIGetOnOffTimeAppRequest(JSONObject jObject){
		int serviceID = API_KEY_ONOFF_APP;
		Vector<Object> v = new Vector<Object>(vectorSize);
		v.add(getURL(serviceID));	
		v.add(jObject);	
		v.add(serviceID);
		v.add(1);
		return v;	
	}
	public Vector<Object> getAPIGetOnOffTimeScreenRequest(JSONObject jObject){
		int serviceID = API_KEY_ONOFF_SCREEN;
		Vector<Object> v = new Vector<Object>(vectorSize);
		v.add(getURL(serviceID));	
		v.add(jObject);	
		v.add(serviceID);
		v.add(1);
		return v;	
	}
	public Vector<Object> getAPIGetOnOffTimeBoxRequest(JSONObject jObject){
		int serviceID = API_KEY_ONOFF_BOX;
		Vector<Object> v = new Vector<Object>(vectorSize);
		v.add(getURL(serviceID));	
		v.add(jObject);	
		v.add(serviceID);
		v.add(1);
		return v;	
	}
	
public Vector<Object> getAPIGetOnOffTimeListBoxRequest(String jObject){
	int serviceID = API_KEY_ONOFF_BOX_OFFLINE;
	Vector<Object> v = new Vector<Object>(vectorSize);
	v.add(getURL(serviceID));	
	v.add(jObject);	
	v.add(serviceID);
	v.add(3);
	return v;	
}
public Vector<Object> getAPIGetOnOffTimeListScreenRequest(String jObject){
	int serviceID = API_KEY_ONOFF_SCREEN_OFFLINE;
	Vector<Object> v = new Vector<Object>(vectorSize);
	v.add(getURL(serviceID));	
	v.add(jObject);	
	v.add(serviceID);
	v.add(3);
	return v;	
}
public Vector<Object> getAPIGetOnOffTimeListAppRequest(String jObject){
	int serviceID = API_KEY_ONOFF_APP_OFFLINE;
	Vector<Object> v = new Vector<Object>(vectorSize);
	v.add(getURL(serviceID));	
	v.add(jObject);	
	v.add(serviceID);
	v.add(3);
	return v;	
}
public Vector<Object> getAPIGetLayoutListAppRequest(String jObject){
	int serviceID = API_KEY_LAYOUT_TIME_OFFLINE;
	Vector<Object> v = new Vector<Object>(vectorSize);
	v.add(getURL(serviceID));	
	v.add(jObject);	
	v.add(serviceID);
	v.add(3);
	return v;	
}
public Vector<Object> getAPIGetMediaListAppRequest(String jObject){
	int serviceID = API_KEY_MEDIA_TIME_OFFLINE;
	Vector<Object> v = new Vector<Object>(vectorSize);
	v.add(getURL(serviceID));	
	v.add(jObject);	
	v.add(serviceID);
	v.add(3);
	return v;	
}
//	
//	public Vector<Object> getAPIGetRegisterRequest(String deviceId){
//		int serviceID = API_KEY_REGISTER_DEVICE;
//		Vector<Object> v = new Vector<Object>(vectorSize);
//		v.add(getURL(serviceID)+deviceId);	
//		JSONObject jObject = new JSONObject();
//
////		try {
////////			getFileInfo();
//////			jObject.put("emailId", userName);
//////			jObject.put("password", password);
//////			jObject.put("phoneNumber", phoneNumber);
////		}catch (Exception e) {
////			e.printStackTrace();
////		}		
//		v.add(jObject);	
//		v.add(serviceID);
//		return v;	
//	}
//	
//	public Vector<Object> getAPIGetCameraAddedCheck(String userName){
//		int serviceID = API_KEY_VIEW_CAMERA;
//		Vector<Object> v = new Vector<Object>(vectorSize);
//		String addUrl = getURL(serviceID)+userName;
//		v.add(addUrl);	
////		JSONObject jObject = new JSONObject();
////
////		try {
//////			getFileInfo();
////			jObject.put("emailId", userName);
////			jObject.put("password", password);
////			jObject.put("phoneNumber", phoneNumber);
////		} catch (JSONException e) {
////			 e.printStackTrace();
////		} catch (Exception e) {
////			e.printStackTrace();
////		}		
////		v.add(jObject);	
//		v.add(serviceID);
//		return v;	
//	}

	private String getCurrentDate(){
		String date = ""+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
		return date;
	}

//	public Vector<Object> getAPIGetPreRegDevice(String deviceId, String assetId){
//		int serviceID = API_KEY_PRE_REG_DEMO;
//		Vector<Object> v = new Vector<Object>(vectorSize);
//		String addUrl = getURL(serviceID);
//		v.add(addUrl);	
//		JSONObject jObject = new JSONObject();
//
//		try {
////			getFileInfo();
//			jObject.put("deviceId", deviceId);
//			jObject.put("assetId", assetId);
//		} catch (JSONException e) {
//			 e.printStackTrace();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}		
//		v.add(jObject);	
//		v.add(serviceID);
//		return v;	
//	}
//
//	
//	public String getAPIUploadImageURL(){
//		int serviceID = API_KEY_UPLOAD_IMAGE;
////		Vector<Object> v = new Vector<Object>(vectorSize);
////		"http://172.16.0.6:8081/mcare/uploadFile.html"
//		return AppConfig.base_URL+"/mcare/uploadFile.html";			
////		return v;	
//	}



	public String getUrl(int urlKey){
		return getURL(urlKey);
	}

	public String getDownloadBaseUrl(){
		return "http://54.251.255.172/demo-repo/";
	}


}
