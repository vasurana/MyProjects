package in.com.app.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LayoutTimeData extends DataParent{

    public String id = null;
    public String boxId = null;
    public String layoutId = null;
    public String  startTime = null;
    public String  endTime = null;

	public String getId() {
			return getValidatedString(id);
		}
		public void setId(String id) {
			this.id = id;
		}

		public String getStbId() {
			return getValidatedString(boxId);
		}
		public void setStbId(String stbId) {
			this.boxId = stbId;
		}
		public String getLayoutID() {
			return getValidatedString(layoutId);
		}
		public void setLayoutID(String layoutID) {
			this.layoutId = layoutID;
		}

		public String getStartTime() {
			return getValidatedString(startTime);
		}
		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}
		public String getEndTime() {
			return getValidatedString(endTime);
		}
		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}

		
	}
