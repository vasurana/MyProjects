package in.com.app;

import in.com.app.background.StateMachineDisplay;
import in.com.app.data.LogData;
import in.com.app.data.SignageData;
import in.com.app.domain.DisplayLayoutFile;
import in.com.app.domain.DisplayLayoutFiles;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;
import in.com.app.utility.Utility;
import in.com.app.wsdl.XMDS;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;


/**
 * This class is wrapper for a asyncTask that downloads individual files from server.
 * @author Ravi@Xvidia
 * @since version 1.0
 *
 */
public class DownloadIndividualFile extends
AsyncTask<ArrayList<DisplayLayoutFile>, Void, ArrayList<String>> implements IDisplayLayout {
	
	Context context = null;
	Activity activity = null;
	boolean downloadFail = false;
	String filename = "";
	
	DownloadIndividualFile(Context ctx, Activity act,String file){
		context = ctx;
		activity = act;
		filename = file;
	}
	

	@Override
	protected ArrayList<String> doInBackground(ArrayList<DisplayLayoutFile>... params) {			
		try{
			ArrayList<DisplayLayoutFile> filesToDownload = params[0];
			XMDS xmds = new XMDS(ClientConnectionConfig._SERVERURL);
			ArrayList<String> fileList = new ArrayList<String>();
			for (DisplayLayoutFile file : filesToDownload) {

				if (!file.getType().equalsIgnoreCase(_BLACKLIST_CATEGORY) ) {
					String fileID = file.getId();
					String fileType = file.getType();
					String fileName = file.getPath();
					if(filename != null && !filename.isEmpty()){
						if(fileName.equals(filename)){
						
							if(file.getSize()!= null){
							int fileSize = Integer.parseInt(file.getSize());
							byte[] bytesData = new byte[fileSize];
							int chunkSize = _CHUNK_SIZE_512_KB;  ///MAGIC NUMBER SIZE DEFINED IN THE XIBO SPECIFICATION 
							
									if(fileType.equals(_FILE_TYPE_LAYOUT))
										fileSize=0;// PASS CHUNK SIZE AS 0 :: MANDATORY IF TYPE IS LAYOUT OR BLACKLIST
									if(fileSize <=chunkSize){
										//							PASS CHUNK SIZE AS FILE SIZE IF FILESIZE LESS THAN OR EQUAL TO CHUNKSIZE
										try{
											bytesData =( xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , 0, fileSize/*file size*/, ClientConnectionConfig._VERSION)).toBytes();
										}catch (Exception e) {
										}
									}	
				
									if(bytesData!=null && !downloadFail){
										saveFileToDisc( fileName,bytesData);
										DataCacheManager.getInstance(AppMain.getAppMainContext()).saveMediaData(fileName);
//										SignageData.getInstance().addRawDataNode(StateMachineDisplay.gi(context,activity).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
										
									}
												
							}
						}
					}else{
						if(fileName.endsWith(".js")){
							continue;
						}
						fileList.add(fileName);						
						int fileSize = Integer.parseInt(file.getSize());
						byte[] bytesData = new byte[fileSize];
						int chunkSize = _CHUNK_SIZE_512_KB;  ///MAGIC NUMBER SIZE DEFINED IN THE XIBO SPECIFICATION 
						if(!Utility.IsFileExists(fileName,true)){
							if(!Utility.IsFileExistsInDownload(fileName)){
								if(fileType.equals(_FILE_TYPE_LAYOUT))
									fileSize=0;// PASS CHUNK SIZE AS 0 :: MANDATORY IF TYPE IS LAYOUT OR BLACKLIST
								if(fileSize <=chunkSize){
									//							PASS CHUNK SIZE AS FILE SIZE IF FILESIZE LESS THAN OR EQUAL TO CHUNKSIZE
									try{
										bytesData =( xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , 0, fileSize/*file size*/, ClientConnectionConfig._VERSION)).toBytes();
										if(bytesData ==null){
											downloadFail = true;
										}
									}catch (Exception e) {
										downloadFail = true;
			//							e.printStackTrace();
									}
								}else{
			
									int startByte = 0;
									int reRequestCounter = fileSize / chunkSize;
									if(fileSize%chunkSize > 0 ){
										reRequestCounter++;
									}
									for(int i =0 ;i<reRequestCounter;i++){
										try{
											if (i + 1 == reRequestCounter) {
												chunkSize = fileSize % chunkSize;
											}
											byte[] temp = (xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , startByte, chunkSize, ClientConnectionConfig._VERSION)).toBytes();		
			
											if(temp!=null){
												for(int byteCount = 0 ; byteCount < temp.length; byteCount++){
													bytesData[startByte++] = temp[byteCount];
												}
											}else{
												downloadFail = true;
//												Log.d(getClass().getName(),"TEMP NULL");
											}
											temp = null;	
										}catch (Exception e) {
											downloadFail = true;
//											Log.d(getClass().getName(),e.getMessage());
										}
									}
									if(bytesData.length != fileSize ){
										downloadFail = true;								
									}
								}
			
								//						String fileUniqueId = fileType+"_"+fileID;
			
								if(bytesData!=null && !downloadFail){					
									saveFileToDisc(fileName,bytesData);
									DataCacheManager.getInstance(AppMain.getAppMainContext()).saveMediaData(fileName);
//									SignageData.getInstance().addRawDataNode(StateMachineDisplay.gi(context,activity).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
			
								}
							}else{
								DataCacheManager.getInstance(AppMain.getAppMainContext()).saveMediaData(fileName);
//								SignageData.getInstance().addRawDataNode(StateMachineDisplay.gi(context,activity).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
									
							}
						}else{
							DataCacheManager.getInstance(AppMain.getAppMainContext()).saveMediaData(fileName);
//							SignageData.getInstance().addRawDataNode(StateMachineDisplay.gi(context,activity).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
							
						}
					}
				}
			}
		}catch (Exception e) {
			downloadFail = true;
//			e.printStackTrace();
		}
		return null; 
	}



	//		String mapDataStringToSave = "";

//	/***
//	 * @deprecated
//	 * @param filename
//	 * @param byteData
//	 * @return
//	 * @throws IOException
//	 */
//	private String saveFileToDisc1(String filename, byte[] byteData) throws IOException{
//		String PATH = Environment.getExternalStorageDirectory()
//				+ "/download/";
//		//filename = filename.concat(".mp4");
//		File checkFile = new File(PATH, filename);
//		
//		try {
//			checkFile.delete();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		File file = new File(PATH);
//		file.mkdirs();
//		File outputFile = new File(file, filename);
//
//
//		FileOutputStream fos = new FileOutputStream(outputFile);
//
//		fos.write(byteData);
//		fos.close();
//
//		return PATH + filename;
//
//	}
//	
	private String saveFileToDisc(String filename, byte[] byteData) throws IOException{
//		String PATH = Environment.getExternalStorageDirectory()
//				+ "/download/";
		
		String PATH = Environment.getExternalStorageDirectory()
				+ AppState.DISPLAY_FOLDER;
		//filename = filename.concat(".mp4");
		File checkFile = new File(PATH, filename);

		try {
			checkFile.delete();
		} catch (Exception e) {
//			e.printStackTrace();
		}

		File file = new File(PATH);
		//if(file.isDirectory()){
			if(!file.exists())
				file.mkdirs();
		//}
		File outputFile = new File(file, filename);


		FileOutputStream fos = new FileOutputStream(outputFile);

		fos.write(byteData);
		fos.close();

		return PATH + filename;

	}

	@Override
	protected void onPostExecute(final ArrayList<String> data) {
		boolean nextStepFlag = false;
		if(SignageData.getInstance().getRawDataNode().size()>0){	
			//				DataCacheManager.getInstance().saveSettingData(_KEY_XIBO_LAST_DISPLAY_RESOURCE_MAP, mapDataStringToSave);
			nextStepFlag = true;
			//copy files from download to Display
			try {
				if(!downloadFail){
//					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_TRUE);
//				
//					String destPath = Environment.getExternalStorageDirectory()
//							+ AppState.DISPLAY_FOLDER;
//					String sourcePath = Environment.getExternalStorageDirectory()
//							+ AppState.DOWNLOAD_FOLDER;
//					 File sourceLocation = new File (sourcePath);
//					 File targetLocation = new File (destPath);
//					 
//					 
//					 FileManager.copyDirectoryOneLocationToAnotherLocation(sourceLocation, targetLocation);
//					 FileManager.deleteDir(sourceLocation);
//
//
//					 String xml = DataCacheManager.getInstance().readSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML);
//						DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
////						DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
//						LogData.getInstance().setCurrentDisplayFilesXml(AppMain.getAppMainContext(), xml);
//					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML,"");
//					appmainInstance.downloadFailed = false;
				}else{
//					appmainInstance.downloadFailed = true;
//					DataCacheManager.getInstance().saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
				}
			} catch (Exception e) {
				DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
			
			}
		}
		if(filename != null && !filename.isEmpty())
			StateMachineDisplay.gi(context,activity).initProcess(nextStepFlag, StateMachine.SHOWDISPLAY);	
//		new DeletFileTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void)null);
	}

//private class DeletFileTask extends AsyncTask<Void, Void, String> {
//		
//		public DeletFileTask() {
//			
//		}
//
//		@Override
//		protected String doInBackground(Void... params) {
//			try {
//				Utility.deleteLeastUsedFileOnLowMemory();
//				return null;
//			} catch (Exception e) {
//				return "";
////				e.printStackTrace();
//			}
//			
//		}
//		
//		@Override
//		protected void onPostExecute(final String data) {
//		}
//			
//	}

}