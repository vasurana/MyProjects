package in.com.app;

import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import in.com.app.data.LogData;
import in.com.app.data.SignageData;
import in.com.app.domain.DisplayLayoutFile;
import in.com.app.network.ServiceURLManager;
import in.com.app.storage.caching.sqlight.manager.DataCacheManager;
import in.com.app.updater.LogUtility;
import in.com.app.utility.Utility;
import in.com.app.wsdl.XMDS;


/**
 * This class is wrapper for a asyncTask that downloads individual files from server.
 * @author Ravi@Xvidia
 * @since version 1.0
 *
 */
    public class StartDownloadIndividualFiles extends
    AsyncTask<ArrayList<DisplayLayoutFile>, Void, ArrayList<String>> implements IDisplayLayout {

    AppMain appmainInstance = null;
    boolean downloadFail = false;
    int downloadedSize = 0;
    int totalSize = 0;
    static private Runnable refreshRunnable;
    static Handler refreshHandler = null;
    final int _TIME_TO_REHIT_SERVER =15*1000;//5*60*1000;
    ArrayList<DisplayLayoutFile> filesToDownload;
    String download_file_path = "http://54.251.255.172/demo-repo/";
    StartDownloadIndividualFiles(AppMain appmain){
		appmainInstance = appmain;
	}
	

	@Override
		protected ArrayList<String> doInBackground(ArrayList<DisplayLayoutFile> ... params) {	
		try{
			filesToDownload = params[0];
			ArrayList<String> fileList = new ArrayList<String>();
			int totalCount = filesToDownload.size();
//            totalCount = totalCount -11;
			int count = 0;
            appmainInstance.runOnUiThread(new Runnable() {
                public void run() {
                    appmainInstance.dialog.show();
                    AppMain.textViewInfo.setVisibility(View.GONE);
                }
            });

            downloadFail = false;
			for (DisplayLayoutFile file : filesToDownload) {
				if (!file.getType().equalsIgnoreCase(_BLACKLIST_CATEGORY) ) {
					String fileID = file.getId();
					String fileType = file.getType();
					String fileName = file.getPath();
					if(fileType != null && fileType.contains("resource")){
						count++;
						continue;
					}
                    if(fileName == null){
                        count++;
                        continue;
                    }else if(fileName.isEmpty()){
                        count++;
                        continue;
                    }
					if(fileName.endsWith(".js")){
						count++;
						continue;
					}
					if(fileType != null && !fileType.equals(_FILE_TYPE_LAYOUT)){
						fileList.add(fileName);
					}

					if(file.getSize()!= null){
					int fileSize = Integer.parseInt(file.getSize());
                        boolean downloadFileFlag = false;
//					byte[] bytesData = new byte[fileSize];
//					int chunkSize = _CHUNK_SIZE_512_KB;  ///MAGIC NUMBER SIZE DEFINED IN THE XIBO SPECIFICATION
                        if(Utility.IsFileExists(fileName,true)) {
                            String PATH = Environment.getExternalStorageDirectory()
                                    + AppState.DISPLAY_FOLDER;
                            File checkFile = new File(PATH,fileName);
                            long size = checkFile.length();
                            if(size<fileSize){
                                downloadFileFlag = true;
                            }
                        }
					if(!Utility.IsFileExists(fileName,true)|| downloadFileFlag){
						if(Utility.IsFileExistsInDownload(fileName)) {
							String PATH = Environment.getExternalStorageDirectory()
									+ AppState.DOWNLOAD_FOLDER;
							File checkFile = new File(PATH,fileName);
							long size = checkFile.length();
                            if(size<fileSize){
                                downloadFileFlag = true;
                            }
						}
                        if(!Utility.IsFileExistsInDownload(fileName) || downloadFileFlag) {
                            if(fileType.equals(_FILE_TYPE_LAYOUT)){
                                byte[] bytesData = new byte[fileSize];
                                try{
                                    count++;
                                    final String message = "Downloading " + count + " / " + totalCount + "\nFile name: " + fileName;
                                    appmainInstance.runOnUiThread(new Runnable() {
                                        public void run() {
                                            appmainInstance.dialogtext.setText(message);
                                        }
                                    });
                                    XMDS xmds = new XMDS(ClientConnectionConfig._SERVERURL);
                                    bytesData =( xmds.GetFile(ClientConnectionConfig._UNIQUE_SERVER_KEY, ClientConnectionConfig._HARDWAREKEY, fileID, fileType , 0, fileSize/*file size*/, ClientConnectionConfig._VERSION)).toBytes();
									if(bytesData != null){
                                        saveFileToDisc(fileName,bytesData);
									}
                                }catch (Exception e) {
                                    downloadFail = true;
                                    //								e.printStackTrace();
                                }
                            }else {
                                downloadFileFlag = false;
                                try {
                                    downloadedSize = 0;
                                    totalSize = 0;
                                    count++;
                                    final String message = "Downloading " + count + " / " + totalCount + "\nFile name: " + fileName;
                                    appmainInstance.runOnUiThread(new Runnable() {
                                        public void run() {
                                            appmainInstance.dialogtext.setText(message);
                                        }
                                    });
                                    download_file_path = new ServiceURLManager().getDownloadBaseUrl() + fileName;
                                    URL url = new URL(download_file_path);
                                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                                    urlConnection.setRequestMethod("GET");
                                    urlConnection.setDoOutput(true);
                                    urlConnection.connect();

                                    String PATH = Environment.getExternalStorageDirectory()
                                            + AppState.DOWNLOAD_FOLDER;
                                    File checkFile = new File(PATH, fileName);
                                    try {
                                        checkFile.delete();
                                    } catch (Exception e) {
                                    }

                                    File saveFile = new File(PATH);
                                    if (!saveFile.exists())
                                        saveFile.mkdirs();
                                    int respCode = urlConnection.getResponseCode();
                                    if (respCode == HttpURLConnection.HTTP_OK) {
                                        Log.e("IP download_file_path", "" + respCode);
                                        File outputFile = new File(PATH, fileName);
                                        FileOutputStream fileOutput = new FileOutputStream(outputFile);
                                        InputStream inputStream = urlConnection.getInputStream();
                                        totalSize = urlConnection.getContentLength();
                                        if (totalSize > 0) {
                                            totalSize = (totalSize / 1024);
                                        }
                                        appmainInstance.runOnUiThread(new Runnable() {
                                            public void run() {
                                                appmainInstance.pb.setMax(totalSize);
                                            }
                                        });
                                        //create a buffer...
                                        byte[] buffer = new byte[1024];
                                        int bufferLength = 0;

                                        while ((bufferLength = inputStream.read(buffer)) > 0) {
                                            fileOutput.write(buffer, 0, bufferLength);
                                            downloadedSize += bufferLength;
                                            // update the progressbar //
                                            final int downloadSize = (downloadedSize / 1024);
                                            appmainInstance.runOnUiThread(new Runnable() {
                                                public void run() {
                                                    appmainInstance.pb.setProgress(downloadSize);
                                                    float per = ((float) downloadSize / totalSize) * 100;
                                                    appmainInstance.cur_val.setText("Download in progress " + downloadSize + "KB / " + totalSize + "KB (" + (int) per + "%)");
                                                }
                                            });
                                        }
                                        fileOutput.close();
                                    } else {
                                        downloadFail = true;
                                    }
                                } catch (final MalformedURLException e) {
                                    downloadFail = true;
                                    Log.e("MalformedURLException", "" + e.getMessage());
                                } catch (final IOException e) {
                                    downloadFail = true;
                                    Log.e("IOException", "" + e.getMessage());
                                } catch (final Exception e) {
                                    downloadFail = true;
                                    Log.e("Exception", "" + e.getMessage());
                                }
                            }
//                            if(fileSize != downloadedSize){
//                                Log.e("ExdownloadedSize", "" + downloadedSize);
//                                refreshScreen();
//                            }
							if( !downloadFail){
								SignageData.getInstance().addRawDataNode(StateMachine.gi(appmainInstance).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
							}
						
						}else{
                            SignageData.getInstance().addRawDataNode(StateMachine.gi(appmainInstance).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);
						}
					}else{
						SignageData.getInstance().addRawDataNode(StateMachine.gi(appmainInstance).getUniqueFileId(fileType, fileID), fileName, fileType, fileSize);

					}
					
				}
				}
			}
			FileManager.setFileArrayListNottoDelete(fileList);
		}catch (Exception e) {
			downloadFail = true;
		}
		return null; 
	}

    private String saveFileToDisc(String filename, byte[] byteData) throws IOException{
//		String PATH = Environment.getExternalStorageDirectory()
//				+ "/download/";

        String PATH = Environment.getExternalStorageDirectory()
                + AppState.DOWNLOAD_FOLDER;
        //filename = filename.concat(".mp4");
        File checkFile = new File(PATH, filename);

        try {
            checkFile.delete();
        } catch (Exception e) {
//			e.printStackTrace();
        }

        File file = new File(PATH);
        //if(file.isDirectory()){
        if(!file.exists())
            file.mkdirs();
        //}
        File outputFile = new File(file, filename);


        FileOutputStream fos = new FileOutputStream(outputFile);

        fos.write(byteData);
        fos.close();

        return PATH + filename;

    }

    void refreshScreen(){
        try {
			if(refreshHandler != null){
				refreshHandler.removeCallbacks(refreshRunnable);
				refreshHandler = null;
				}
            if(refreshHandler== null){
                refreshRunnable = new Runnable() {
                    @Override
                    public void run() {
                        if(LogUtility.checkNetwrk(appmainInstance.getApplicationContext())){
//                            doInBackground(filesToDownload);

                            new StartDownloadIndividualFiles(appmainInstance).execute(filesToDownload);
                        }else{

                            if(refreshHandler != null && refreshRunnable != null){
                                refreshHandler.postDelayed(refreshRunnable, _TIME_TO_REHIT_SERVER);
                            }else{
                                refreshHandler =  new Handler();
                                refreshHandler.postDelayed(refreshRunnable, _TIME_TO_REHIT_SERVER);
                            }
                        }
                    }
                };
                refreshHandler =  new Handler();
                refreshHandler.postDelayed(refreshRunnable, _TIME_TO_REHIT_SERVER);
            }else{
                if(refreshHandler != null) {
                    refreshHandler.postDelayed(refreshRunnable, 10000);
                }else{
                    refreshHandler =  new Handler();
                    refreshHandler.postDelayed(refreshRunnable, _TIME_TO_REHIT_SERVER);
                }
            }
        }catch (Exception e) {
            refreshScreen();
        }

    }
	@Override
	protected void onPostExecute(final ArrayList<String> data) {
		boolean nextStepFlag = false;
		if(SignageData.getInstance().getRawDataNode().size()>0){
            nextStepFlag = true;

			try {
				if(!downloadFail){
					DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_TRUE);
//				
					String destPath = Environment.getExternalStorageDirectory()
							+ AppState.DISPLAY_FOLDER;
					String sourcePath = Environment.getExternalStorageDirectory()
							+ AppState.DOWNLOAD_FOLDER;
					 File sourceLocation = new File (sourcePath);
					 File targetLocation = new File (destPath);
					 
					 FileManager.copyDirectoryOneLocationToAnotherLocation(sourceLocation, targetLocation);
					 FileManager.deleteDir(sourceLocation);

					 String xml = DataCacheManager.getInstance(AppMain.getAppMainContext()).readSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML);
						DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
//						DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_CURRENT_DISPLAY_XML,xml);
						LogData.getInstance().setCurrentDisplayFilesXml(AppMain.getAppMainContext(), xml);
					DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_NEW_DISPLAY_XML,"");
					appmainInstance.downloadFailed = false;

				}else{
					appmainInstance.downloadFailed = true;
					DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
				}
			} catch (IOException e) {
				appmainInstance.downloadFailed = true;
				DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
			
			}
            if(!appmainInstance.downloadFailed){
                appmainInstance.runOnUiThread(new Runnable() {
                    public void run() {
                        appmainInstance.dialog.dismiss(); // if you want close it..
                    }
                });
                StateMachine.gi(appmainInstance).initProcess(nextStepFlag, StateMachine.SHOWDISPLAY);
            }else{
                appmainInstance.downloadFailed = true;
                appmainInstance.runOnUiThread(new Runnable() {
                    public void run() {
                        appmainInstance.cur_val.setText("Download in progress " );
                    }
                });
                DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        StateMachine.gi(appmainInstance).initProcess(false, StateMachine.SHOWDISPLAY);
                    }
                }, 30000);
            }

        }else{
            appmainInstance.downloadFailed = true;
            appmainInstance.runOnUiThread(new Runnable() {
                public void run() {
                    appmainInstance.cur_val.setText("Download in progress " );
                }
            });
            DataCacheManager.getInstance(AppMain.getAppMainContext()).saveSettingData(_KEY_XVIDIA_STATE_INDIVIDUALFILE_COMPLETE, FLAG_FALSE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    StateMachine.gi(appmainInstance).initProcess(false, StateMachine.SHOWDISPLAY);
                }
            }, 30000);
        }

		if(StateMachine.gi(appmainInstance).receivedFilesDownloadLater != null){
			LogData.getInstance().setDownloadPending(appmainInstance, true);
		}
	}
}