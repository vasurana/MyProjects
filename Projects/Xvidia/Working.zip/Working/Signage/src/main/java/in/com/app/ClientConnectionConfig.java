package in.com.app;

/**
 * This class has static fields for server connections.
 * @author Ravi@Xvidia
 * @since version 1.0
 *
 */
public class ClientConnectionConfig {
//	public static final String _SERVERURL = "http://54.254.103.114/signagedemo/xmds.php";
//	public static final String _SERVERURL = "http://dss.amosta.com/xmds.php";

	public static final String _SERVERURL = "http://54.251.255.172/signagedemo/xmds.php";
	//	public static final String _SERVERURL = "http://192.168.1.9/xibo172/xmds.php";
	public static final String _UNIQUE_SERVER_KEY = "7f0hRO";//"iwah3l";//"8cngZ1";//EXMA58";//"pkb@bj1757";// [iwah3l]
//	public static final String _UNIQUE_SERVER_KEY = "f9jbrl";
	public static String _HARDWAREKEY = "";
	public static String _DISPLAYNAME = "";
	public static String _ADDRESS = "";
	public static String _ASSETID = "";
	public static String LAST_REQUEST_DATA = "";
	public static String _VERSION = "4";
}
